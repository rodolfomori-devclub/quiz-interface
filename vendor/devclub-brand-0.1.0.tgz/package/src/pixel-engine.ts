/**
 * Motor de partículas da logo pixel — v3 "cinema total".
 * O canvas cobre o hero INTEIRO. Três camadas de profundidade:
 *   0 · logo  — os 284 sub-pixels que formam a marca (vêm das bordas da tela)
 *   1 · ambiente — pixels soltos vagando ao fundo (paralaxe leve)
 *   2 · bokeh — poucos pixels grandes e difusos em primeiro plano (paralaxe forte)
 * Câmera com push-in no assemble + paralaxe de ponteiro + onda de choque no
 * lock-in. `intro` e `scroll` seguem eixos independentes (reversível sempre).
 */
import { LOGO } from './logo-matrix'

export interface Particle {
  layer: 0 | 1 | 2
  /** alvo em células (camada 0) ou casa em coords normalizadas (1/2) */
  tx: number
  ty: number
  /** origem espalhada, normalizada (0-1 da tela) */
  sx: number
  sy: number
  /** vetor de explosão do dissolve (normalizado) */
  ex: number
  ey: number
  delay: number
  size: number
  twPhase: number
  twSpeed: number
  glint: boolean
  /** órbita do idle (camadas 1/2) */
  orbR: number
  orbSpeed: number
  /** deslocamento persistente de "areia" (impulso do mouse, assenta com decay) */
  ox: number
  oy: number
}

function mulberry32(seed: number) {
  let a = seed
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

const SUB = 2

export function createScene(): Particle[] {
  const rand = mulberry32(0x39d353)
  const particles: Particle[] = []
  const { matrix, rows, cols } = LOGO

  // camada 0 — a logo, nascendo das BORDAS da tela (impacto amplo)
  for (let y = 0; y < rows; y++) {
    for (let x = 0; x < cols; x++) {
      if (!matrix[y]?.[x]) continue
      for (let sy = 0; sy < SUB; sy++) {
        for (let sx = 0; sx < SUB; sx++) {
          const edge = rand()
          // origem: fora/na borda da viewport, em todas as direções
          const from =
            edge < 0.25
              ? { sx: rand() * 1.2 - 0.1, sy: -0.08 - rand() * 0.15 }
              : edge < 0.5
                ? { sx: rand() * 1.2 - 0.1, sy: 1.08 + rand() * 0.15 }
                : edge < 0.75
                  ? { sx: -0.08 - rand() * 0.12, sy: rand() }
                  : { sx: 1.08 + rand() * 0.12, sy: rand() }
          const exAngle = rand() * Math.PI * 2
          const exDist = 0.25 + rand() * 0.6
          particles.push({
            layer: 0,
            tx: x + (sx + 0.5) / SUB,
            ty: y + (sy + 0.5) / SUB,
            ...from,
            ex: Math.cos(exAngle) * exDist,
            ey: Math.abs(Math.sin(exAngle)) * exDist + 0.2, // viés p/ baixo
            delay: rand(),
            size: 0.72 + rand() * 0.28,
            twPhase: rand() * Math.PI * 2,
            twSpeed: 0.6 + rand() * 1.8,
            glint: rand() < 0.06,
            orbR: 0,
            orbSpeed: 0,
            ox: 0,
            oy: 0,
          })
        }
      }
    }
  }

  // camada 1 — ambiente (44 pixels soltos vagando)
  for (let i = 0; i < 44; i++) {
    particles.push({
      layer: 1,
      tx: rand(),
      ty: rand(),
      sx: rand(),
      sy: rand(),
      ex: (rand() - 0.5) * 0.8,
      ey: rand() * 0.6 + 0.1,
      delay: rand() * 0.4,
      size: 1.6 + rand() * 2.4,
      twPhase: rand() * Math.PI * 2,
      twSpeed: 0.3 + rand() * 1.2,
      glint: false,
      orbR: 0.006 + rand() * 0.014,
      orbSpeed: 0.08 + rand() * 0.2,
      ox: 0,
      oy: 0,
    })
  }

  // camada 2 — bokeh próximo (12 pixels grandes e difusos)
  for (let i = 0; i < 12; i++) {
    particles.push({
      layer: 2,
      tx: rand(),
      ty: rand(),
      sx: rand(),
      sy: rand(),
      ex: (rand() - 0.5) * 1.2,
      ey: rand() * 0.8 + 0.2,
      delay: rand() * 0.3,
      size: 10 + rand() * 10,
      twPhase: rand() * Math.PI * 2,
      twSpeed: 0.2 + rand() * 0.5,
      glint: false,
      orbR: 0.012 + rand() * 0.02,
      orbSpeed: 0.05 + rand() * 0.12,
      ox: 0,
      oy: 0,
    })
  }

  return particles
}

const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3)
const easeInCubic = (t: number) => t * t * t
const clamp01 = (t: number) => Math.min(1, Math.max(0, t))

export interface SceneState {
  intro: number
  scroll: number
  time: number
  flash: number
  sweep: number
  /** onda de choque do lock-in (0 = inativa) */
  shock: number
  /** push-in de câmera (1.08 → 1 no assemble) */
  zoom: number
  /** paralaxe do ponteiro, -0.5..0.5 (lerp feito pelo caller) */
  px: number
  py: number
  /** posição do ponteiro em px do canvas (lerp no caller) + intensidade 0-1 */
  mx: number
  my: number
  mouse: number
  trails: boolean
  /** multiplicador global de alpha (mobile: logo fica atrás do conteúdo) */
  alphaMul: number
}

export function drawScene(
  ctx: CanvasRenderingContext2D,
  particles: Particle[],
  w: number,
  h: number,
  state: SceneState,
  color = '#39d353'
) {
  const { intro, scroll, time, flash, sweep, shock, zoom, px, py, mx, my, mouse, trails, alphaMul } = state

  if (trails) {
    ctx.globalCompositeOperation = 'destination-out'
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)'
    ctx.fillRect(0, 0, w, h)
    ctx.globalCompositeOperation = 'source-over'
  } else {
    ctx.clearRect(0, 0, w, h)
  }

  // geometria da logo: grande, centro-direita no desktop, central no mobile
  const desktop = w >= 1024
  const cell = desktop ? Math.min(h * 0.048, w * 0.027) : Math.min(h * 0.036, w * 0.05)
  const cx = desktop ? w * 0.74 : w * 0.5
  const cy = h * 0.48
  const ox = cx - (LOGO.cols / 2) * cell
  const oy = cy - (LOGO.rows / 2) * cell

  // câmera: zoom em torno do centro da logo + paralaxe por camada
  const idleAmount = clamp01(intro) * (1 - clamp01(scroll * 3))
  // pulso radial MUITO lento: as células se afastam e reaproximam (~40s)
  const pulseT = time * 0.16
  const mouseR = cell * 4

  ctx.save()
  ctx.translate(cx, cy)
  ctx.scale(zoom, zoom)
  ctx.translate(-cx, -cy)

  ctx.fillStyle = color
  for (const p of particles) {
    const depth = p.layer === 0 ? 0.5 : p.layer === 1 ? 0.2 : 1.0
    const parX = px * 18 * depth
    const parY = py * 12 * depth

    let x: number
    let y: number
    let baseAlpha: number
    let size: number

    if (p.layer === 0) {
      const li = clamp01((intro - p.delay * 0.45) / (1 - p.delay * 0.45))
      const ti = easeOutCubic(li)
      const fromX = p.sx * w
      const fromY = p.sy * h
      // direção radial a partir do centro da logo (para o pulso)
      const rdx = p.tx - LOGO.cols / 2
      const rdy = p.ty - LOGO.rows / 2
      const rdist = Math.sqrt(rdx * rdx + rdy * rdy) || 1
      // onda respiratória: parte do centro para fora (fase pela distância),
      // amplitude rasa e comprimento maior = movimento delicado
      const pulse =
        Math.sin(pulseT - rdist * 0.22) * 0.11 * cell * idleAmount
      const toX = ox + p.tx * cell + (rdx / rdist) * pulse
      const toY = oy + p.ty * cell + (rdy / rdist) * pulse
      x = fromX + (toX - fromX) * ti
      y = fromY + (toY - fromY) * ti
      // AREIA: o mouse chuta os grãos (impulso com jitter), que assentam devagar
      if (mouse > 0.01 && idleAmount > 0.05) {
        const mdx = x - mx
        const mdy = y - my
        const md2 = mdx * mdx + mdy * mdy
        // raio IRREGULAR: varia por grão (fase própria) e por ângulo — a borda
        // da zona nunca é um círculo; a média é ~70% do raio nominal
        const angM = Math.atan2(mdy, mdx)
        const rG =
          mouseR *
          (0.7 + 0.2 * Math.sin(p.twPhase * 3.1) + 0.15 * Math.sin(angM * 3 + p.twPhase + time * 0.5))
        if (md2 < rG * rG) {
          const md = Math.sqrt(md2) || 1
          const f = 1 - md / rG
          // direção radial + jitter por grão (fase própria) = espalhamento de areia
          const jitter = (p.twPhase - Math.PI) * 0.4 * f + Math.sin(time * 1.6 + p.twPhase) * 0.18
          const ang = angM + jitter
          // queda CÚBICA: longe do cursor quase nada se move
          const imp = f * f * f * cell * 0.34 * idleAmount * mouse
          p.ox += Math.cos(ang) * imp
          p.oy += Math.sin(ang) * imp + imp * 0.15 // grãos tendem a cair
        }
      }
      // assentamento: decaimento lento de volta ao lugar (grão a grão)
      const settle = 0.962 - (p.twSpeed - 0.6) * 0.006 // cada grão assenta num ritmo
      p.ox *= settle
      p.oy *= settle
      const offMag = Math.sqrt(p.ox * p.ox + p.oy * p.oy)
      const maxOff = cell * 3
      if (offMag > maxOff) {
        p.ox *= maxOff / offMag
        p.oy *= maxOff / offMag
      }
      x += p.ox
      y += p.oy
      const ls = clamp01((scroll - (1 - p.delay) * 0.25) / (1 - (1 - p.delay) * 0.25))
      const ts = easeInCubic(ls)
      x += p.ex * w * ts
      y += p.ey * h * ts + ts * ts * h * 0.25
      const tw =
        idleAmount > 0.01
          ? Math.sin(time * p.twSpeed * 0.55 + p.twPhase) * 0.09 * idleAmount
          : 0
      const glintBoost =
        p.glint && idleAmount > 0.5 && Math.sin(time * 1.3 + p.twPhase * 3) > 0.965 ? 0.28 : 0
      const scatter = clamp01(offMag / (cell * 4))
      baseAlpha = clamp01(
        ((0.2 + 0.8 * ti) * (1 - ts) * (0.82 + tw) + glintBoost + flash * 0.35) *
          (1 - scatter * 0.55)
      )
      size = (cell / SUB) * p.size * (0.4 + 0.6 * ti) * (1 - ts * 0.4) * (1 - scatter * 0.35)
    } else {
      // camadas ambiente/bokeh: órbita lenta + dissolve junto com o scroll
      const angle = time * p.orbSpeed * 0.6 + p.twPhase
      const ts = easeInCubic(clamp01(scroll * 1.4))
      x = (p.tx + Math.cos(angle) * p.orbR) * w + p.ex * w * ts
      y = (p.ty + Math.sin(angle * 1.3) * p.orbR) * h + p.ey * h * ts
      const tw = Math.sin(time * p.twSpeed * 0.7 + p.twPhase) * 0.3
      const maxA = p.layer === 1 ? 0.22 : 0.1
      baseAlpha = clamp01(maxA * (0.6 + tw) * clamp01(intro * 2) * (1 - ts))
      size = p.layer === 1 ? p.size : p.size * (1 + Math.sin(time * 0.3 + p.twPhase) * 0.08)
    }

    const alpha = baseAlpha * alphaMul
    if (alpha <= 0.008) continue
    ctx.globalAlpha = alpha
    if (p.layer === 2) {
      ctx.shadowColor = color
      ctx.shadowBlur = 14
    }
    ctx.fillRect(x + parX - size / 2, y + parY - size / 2, size, size)
    if (p.layer === 2) ctx.shadowBlur = 0
  }

  // onda de choque do lock-in: anel expandindo do centro da logo
  if (shock > 0.001 && shock < 0.999) {
    const maxR = Math.max(w, h) * 0.55
    const r = easeOutCubic(shock) * maxR
    ctx.globalAlpha = (1 - shock) * 0.45 * alphaMul
    ctx.strokeStyle = color
    ctx.lineWidth = 2 + (1 - shock) * 2
    ctx.beginPath()
    ctx.arc(cx, cy, r, 0, Math.PI * 2)
    ctx.stroke()
  }

  // flash radial do lock-in
  if (flash > 0.01) {
    const r = cell * LOGO.cols * 0.9
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, r)
    grad.addColorStop(0, `rgba(57, 211, 83, ${0.3 * flash * alphaMul})`)
    grad.addColorStop(1, 'rgba(57, 211, 83, 0)')
    ctx.globalAlpha = 1
    ctx.fillStyle = grad
    ctx.fillRect(cx - r, cy - r, r * 2, r * 2)
    ctx.fillStyle = color
  }

  // varredura de scanline sobre a logo
  if (sweep > 0.001 && sweep < 0.999) {
    const yLine = oy + sweep * LOGO.rows * cell
    const grad = ctx.createLinearGradient(0, yLine - cell, 0, yLine + cell)
    grad.addColorStop(0, 'rgba(57, 211, 83, 0)')
    grad.addColorStop(0.5, `rgba(57, 211, 83, ${0.5 * alphaMul})`)
    grad.addColorStop(1, 'rgba(57, 211, 83, 0)')
    ctx.globalAlpha = 1
    ctx.fillStyle = grad
    ctx.fillRect(ox - cell, yLine - cell, cell * (LOGO.cols + 2), cell * 2)
    ctx.fillStyle = color
  }

  ctx.restore()
  ctx.globalAlpha = 1
}

export function fitCanvas(canvas: HTMLCanvasElement): { w: number; h: number; dpr: number } {
  const dpr = Math.min(window.devicePixelRatio || 1, 2)
  const rect = canvas.getBoundingClientRect()
  const w = Math.round(rect.width)
  const h = Math.round(rect.height)
  if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
    canvas.width = w * dpr
    canvas.height = h * dpr
    canvas.getContext('2d')?.setTransform(dpr, 0, 0, dpr, 0, 0)
  }
  return { w, h, dpr }
}

export { LOGO }
