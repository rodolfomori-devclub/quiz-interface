'use client'

import * as React from 'react'
import { Sparkles } from 'lucide-react'

const KEY = 'dc-stars'
const EVT = 'dc-stars-change'

/* 60 pixels em posições determinísticas — a marca no céu, atrás de tudo. */
const STARS = Array.from({ length: 60 }, (_, i) => ({
  x: (i * 37 + 13) % 100,
  y: (i * 53 + 7) % 100,
  big: i % 6 === 0,
  green: i % 3 !== 0,
  dur: 2.6 + ((i * 7) % 12) * 0.35,
  delay: ((i * 11) % 24) * 0.25,
  drift: i % 4 === 0,
}))

function isOn() {
  if (typeof window === 'undefined') return true
  return localStorage.getItem(KEY) !== 'off'
}

/**
 * Fundo animado do site (escolha do usuário: com/sem, padrão COM).
 * Tema escuro: constelação de fósforo. Tema claro: aquarela VV2 — manchas
 * d'água de um só verde (h146) em três pesos. CSS puro, atrás de todo o
 * conteúdo; o tema ativo decide qual camada aparece e reduced-motion
 * congela as duas (via globals.css).
 */
export function Starfield() {
  const [on, setOn] = React.useState(true)
  React.useEffect(() => {
    setOn(isOn())
    const sync = () => setOn(isOn())
    window.addEventListener(EVT, sync)
    window.addEventListener('storage', sync)
    return () => {
      window.removeEventListener(EVT, sync)
      window.removeEventListener('storage', sync)
    }
  }, [])

  if (!on) return null
  return (
    <>
      <div className="dc-starfield" aria-hidden>
        {STARS.map((s, i) => (
          <span
            key={i}
            className="dc-star"
            style={{
              left: `${s.x}%`,
              top: `${s.y}%`,
              width: s.big ? 4 : 2,
              height: s.big ? 4 : 2,
              background: s.green ? 'var(--dc-brand)' : 'var(--dc-text-subtle)',
              animation: `dc-tw ${s.dur}s ease-in-out ${s.delay}s infinite${
                s.drift ? `, dc-drift ${s.dur * 4}s ease-in-out ${s.delay}s infinite alternate` : ''
              }`,
              boxShadow: s.big ? '0 0 6px var(--dc-brand-line)' : undefined,
            }}
          />
        ))}
      </div>
      <div className="dc-aquarela" aria-hidden>
        <div className="dc-wash" />
        <div className="dc-wash" />
        <div className="dc-wash" />
      </div>
    </>
  )
}

/** Botão liga/desliga do fundo animado — constelação no escuro, aquarela no claro. */
export function StarsToggle() {
  const [on, setOn] = React.useState(true)
  React.useEffect(() => setOn(isOn()), [])
  const toggle = () => {
    const next = !on
    setOn(next)
    localStorage.setItem(KEY, next ? 'on' : 'off')
    window.dispatchEvent(new Event(EVT))
  }
  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={on ? 'Desligar fundo animado' : 'Ligar fundo animado'}
      onClick={toggle}
      className={`inline-flex size-10 items-center justify-center rounded-md border transition-colors ${
        on
          ? 'border-brand-line bg-brand-subtle text-fg-brand'
          : 'border-line bg-surface text-fg-muted hover:text-fg-subtle'
      }`}
    >
      <Sparkles className="size-5" />
    </button>
  )
}
