# @devclub/brand

Assinaturas visuais do **DevClub Design System** — as peças que fazem uma
tela ser inconfundivelmente DevClub:

- **Motor da logo em pixels** (`createScene`, `drawScene`, `fitCanvas`):
  canvas 2D com a logo 13×13 montando pelas bordas, respiração radial lenta
  e dispersão de areia sob o mouse. Zero dependências.
- **`<Starfield />` + `<StarsToggle />`**: fundo animado dos dois temas —
  constelação de fósforo no escuro, aquarela verde-tonal no claro — com
  botão ✦ de liga/desliga (persistido em `localStorage`).
- **`@devclub/brand/css`**: os estilos das duas camadas + grain do papel
  reciclado do tema claro. Respeita `prefers-reduced-motion`.

## Uso

```tsx
// CSS (depois dos tokens):
// @import '@devclub/tokens/css';
// @import '@devclub/brand/css';

import { Starfield, StarsToggle } from '@devclub/brand'

// <Starfield /> atrás do app + <StarsToggle /> no header. Pronto.
```

Requer `@devclub/tokens` carregado (usa `--dc-brand`, `--dc-text-subtle` etc.)
e tema controlado via atributo `data-theme` (`dark` | `light`) no `<html>`.

Guia completo de aplicação: `docs/guia-de-aplicacao.md` no repositório.

MIT © DevClub
