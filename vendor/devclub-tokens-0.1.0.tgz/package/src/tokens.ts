/**
 * DevClub Design System — tokens como dados (JS/TS).
 * Espelha os valores canônicos definidos em `tokens.css`, para consumo em
 * JS (data-viz, docs, testes de contraste, geração de temas nativos).
 * A fonte da verdade visual continua sendo o CSS; mantenha os dois em sincronia.
 */

export const brand = {
  /** Verde da marca DevClub — #39d353 (extraído da logo) */
  green: '#39d353',
  greenOklch: 'oklch(0.762 0.212 146)',
  navyInk: '#010b23',
  premium: '#b48ef0',
} as const

/** Rampa verde "fósforo" — dark mode (OKLCH). green-9 = a marca. */
export const greenDark = {
  1: 'oklch(0.17 0.022 146)',
  2: 'oklch(0.2 0.032 146)',
  3: 'oklch(0.26 0.05 146)',
  4: 'oklch(0.31 0.068 146)',
  5: 'oklch(0.36 0.086 146)',
  6: 'oklch(0.43 0.104 146)',
  7: 'oklch(0.51 0.126 146)',
  8: 'oklch(0.62 0.17 146)',
  9: 'oklch(0.762 0.212 146)',
  10: 'oklch(0.80 0.20 146)',
  11: 'oklch(0.86 0.18 146)',
  12: 'oklch(0.94 0.08 146)',
} as const

/** Rampa neutra OLED (nome "navy" é legado; croma zero) — dark (OKLCH). */
export const navyDark = {
  1: 'oklch(0.12 0 0)',
  2: 'oklch(0.145 0 0)',
  3: 'oklch(0.19 0 0)',
  4: 'oklch(0.23 0 0)',
  5: 'oklch(0.27 0 0)',
  6: 'oklch(0.32 0 0)',
  7: 'oklch(0.38 0 0)',
  8: 'oklch(0.48 0 0)',
  9: 'oklch(0.58 0 0)',
  10: 'oklch(0.66 0 0)',
  11: 'oklch(0.72 0 0)',
  12: 'oklch(1 0 0)',
} as const

/** Roxo premium — SÓ raro/premium/XP alto. */
export const premium = {
  solid: '#b48ef0',
  solidOklch: 'oklch(0.721 0.143 300.7)',
} as const

export const radius = {
  xs: '0.25rem',
  sm: '0.375rem',
  md: '0.5rem',
  lg: '0.75rem',
  xl: '1rem',
  '2xl': '1.5rem',
  full: '9999px',
} as const

export const duration = {
  fast1: '70ms',
  fast2: '110ms',
  moderate1: '150ms',
  moderate2: '240ms',
  slow1: '400ms',
  slow2: '700ms',
} as const

export const easing = {
  productive: 'cubic-bezier(0.2, 0, 0.38, 0.9)',
  entrance: 'cubic-bezier(0, 0, 0.38, 0.9)',
  exit: 'cubic-bezier(0.2, 0, 1, 0.9)',
  expressive: 'cubic-bezier(0.4, 0.14, 0.3, 1)',
  emphasized: 'cubic-bezier(0.05, 0.7, 0.1, 1)',
} as const

export const fontFamily = {
  display: "'Archivo', 'Space Grotesk', sans-serif",
  sans: "'Space Grotesk', ui-sans-serif, system-ui, sans-serif",
  mono: "'JetBrains Mono', ui-monospace, monospace",
  pixel: "'Silkscreen', ui-monospace, monospace",
  arcade: "'VT323', 'Silkscreen', monospace",
} as const

/** Escala tipográfica semântica (px/rem base). */
export const fontSize = {
  display: 'clamp(2.75rem, 1.9rem + 4.2vw, 4.5rem)',
  h1: '3.5rem',
  h2: '2.5rem',
  h3: '2rem',
  h4: '1.5rem',
  h5: '1.25rem',
  copyLg: '1.125rem',
  copy: '1rem',
  copySm: '0.875rem',
  label: '0.875rem',
  labelSm: '0.8125rem',
  labelXs: '0.75rem',
  eyebrow: '0.75rem',
} as const

export const tokens = {
  brand,
  greenDark,
  navyDark,
  premium,
  radius,
  duration,
  easing,
  fontFamily,
  fontSize,
} as const

export type Tokens = typeof tokens
