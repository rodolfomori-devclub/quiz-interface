# @devclub/tokens

Design tokens do **DevClub Design System** — cores em OKLCH, tipografia, espaçamento e motion, prontos para Tailwind CSS v4.

```bash
pnpm add @devclub/tokens
```

## CSS (Tailwind v4)

```css
@import 'tailwindcss';
@import '@devclub/tokens/css';
```

Isso registra:

- **Variáveis de tema** (`--dc-*`) em `:root` (dark) e `[data-theme="light"]`.
- **Bridge Tailwind** (`@theme`) que gera utilities on-brand: `bg-surface`, `text-fg-subtle`, `border-brand-line`, `text-h1`, `shadow-glow`, `ease-expressive`, etc.
- **Base** (reset, foco verde, scrollbar, seleção) e keyframes de marca (`cursor-blink`, `glow-pulse`, `shimmer`).

A paleta default do Tailwind é zerada (`--color-*: initial`) — só as cores do DevClub existem.

## Arquitetura em 3 camadas

1. **Primitivos** — `--dc-green-1..12`, `--dc-navy-1..12` (rampas OKLCH, mudam por tema).
2. **Semânticos** — `--dc-canvas`, `--dc-surface`, `--dc-text`, `--dc-border`, `--dc-brand` (falam de intenção).
3. **Componente** — definidos nos próprios componentes, consomem os semânticos.

## JS

```ts
import { brand, greenDark, radius, easing } from '@devclub/tokens'

brand.green // '#3ED160'
```

## Entradas

| Import | Conteúdo |
| --- | --- |
| `@devclub/tokens/css` | tudo (tokens + theme + base) |
| `@devclub/tokens/tokens.css` | só as variáveis `--dc-*` |
| `@devclub/tokens/theme.css` | só o bridge `@theme` do Tailwind |
| `@devclub/tokens` | tokens como dados JS/TS |

## Licença

MIT © DevClub
