import * as React from 'react'
import { Slot as SlotPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'
import { Kbd } from '../kbd/kbd'

const { Root: Slot, Slottable } = SlotPrimitive

// Contexto interno: compartilha o estado colapsado com as subpartes, para que
// labels/atalhos sumam quando a sidebar encolhe (sem prop drilling).
interface SidebarContextValue {
  collapsed: boolean
}
const SidebarContext = React.createContext<SidebarContextValue>({ collapsed: false })
const useSidebar = () => React.useContext(SidebarContext)

export interface SidebarProps extends React.HTMLAttributes<HTMLElement> {
  /** Encolhe a sidebar para faixa de ícones e esconde os rótulos. */
  collapsed?: boolean
}

/**
 * Sidebar — navegação lateral estrutural (espinha de apps de escola).
 * Superfície `bg-subtle` separada por borda à direita. Composto: use com
 * SidebarHeader/Content/Footer/Nav/NavItem/Group/GroupLabel. Colapsável via `collapsed`.
 */
export const Sidebar = React.forwardRef<HTMLElement, SidebarProps>(
  ({ className, collapsed = false, children, ...props }, ref) => (
    <SidebarContext.Provider value={{ collapsed }}>
      <aside
        ref={ref}
        data-slot="sidebar"
        data-collapsed={collapsed || undefined}
        className={cn(
          'flex h-full flex-col border-r border-line bg-subtle text-fg',
          'transition-[width] duration-[200ms] ease-productive motion-reduce:transition-none',
          collapsed ? 'w-16' : 'w-64',
          className
        )}
        {...props}
      >
        {children}
      </aside>
    </SidebarContext.Provider>
  )
)
Sidebar.displayName = 'Sidebar'

/** SidebarHeader — topo fixo (logo/marca). */
export const SidebarHeader = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="sidebar-header"
      className={cn('flex h-14 shrink-0 items-center gap-2 px-3', className)}
      {...props}
    />
  )
)
SidebarHeader.displayName = 'SidebarHeader'

/** SidebarContent — corpo rolável que ocupa o espaço restante. */
export const SidebarContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="sidebar-content"
    className={cn('flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto py-3', className)}
    {...props}
  />
))
SidebarContent.displayName = 'SidebarContent'

/** SidebarFooter — rodapé fixo (usuário/ações). */
export const SidebarFooter = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="sidebar-footer"
      className={cn('mt-auto flex shrink-0 flex-col gap-1 border-t border-line-subtle p-3', className)}
      {...props}
    />
  )
)
SidebarFooter.displayName = 'SidebarFooter'

/** SidebarGroup — agrupa itens de navegação relacionados. */
export const SidebarGroup = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="sidebar-group"
      className={cn('flex flex-col gap-1 px-2', className)}
      {...props}
    />
  )
)
SidebarGroup.displayName = 'SidebarGroup'

/** SidebarGroupLabel — título de seção em eyebrow mono; some quando colapsado. */
export const SidebarGroupLabel = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => {
  const { collapsed } = useSidebar()
  if (collapsed) return null
  return (
    <div
      ref={ref}
      data-slot="sidebar-group-label"
      className={cn(
        'px-2 pb-1 pt-2 font-mono text-eyebrow uppercase tracking-caps text-fg-muted',
        className
      )}
      {...props}
    />
  )
})
SidebarGroupLabel.displayName = 'SidebarGroupLabel'

/** SidebarNav — landmark de navegação (`<nav>`). */
export const SidebarNav = React.forwardRef<HTMLElement, React.HTMLAttributes<HTMLElement>>(
  ({ className, ...props }, ref) => (
    <nav
      ref={ref}
      data-slot="sidebar-nav"
      className={cn('flex flex-col gap-4', className)}
      {...props}
    />
  )
)
SidebarNav.displayName = 'SidebarNav'

export const sidebarNavItemVariants = cva(
  [
    'group/nav-item relative flex w-full items-center gap-3 rounded-md px-2.5 py-2 text-left',
    'border-l-2 border-transparent',
    'text-label font-medium text-fg-subtle',
    'transition-[background-color,color,border-color] duration-[110ms] ease-productive',
    'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
    'hover:bg-component hover:text-fg',
    'disabled:pointer-events-none disabled:opacity-50',
    '[&_svg]:size-4.5 [&_svg]:shrink-0 [&_svg]:text-fg-muted',
    'hover:[&_svg]:text-fg',
  ],
  {
    variants: {
      active: {
        true: 'bg-brand-subtle text-fg-brand border-brand hover:bg-brand-subtle-hover hover:text-fg-brand [&_svg]:text-fg-brand hover:[&_svg]:text-fg-brand',
        false: '',
      },
    },
    defaultVariants: { active: false },
  }
)

export interface SidebarNavItemProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof sidebarNavItemVariants> {
  /** Renderiza no filho (ex: `<SidebarNavItem asChild><a href="/aulas"/>`). */
  asChild?: boolean
  /** Ícone à esquerda do rótulo. */
  icon?: React.ReactNode
  /** Atalho de teclado exibido à direita em Kbd (some quando colapsado). */
  shortcut?: string[]
}

/**
 * SidebarNavItem — item de navegação. `active` pinta o trilho verde à esquerda
 * (border-brand + bg-brand-subtle). Aceita ícone, rótulo e atalho opcional.
 */
export const SidebarNavItem = React.forwardRef<HTMLButtonElement, SidebarNavItemProps>(
  ({ className, active = false, asChild = false, icon, shortcut, children, ...props }, ref) => {
    const { collapsed } = useSidebar()
    const Comp = asChild ? Slot : 'button'

    return (
      <Comp
        ref={ref}
        data-slot="sidebar-nav-item"
        data-active={active || undefined}
        aria-current={active ? 'page' : undefined}
        title={collapsed && typeof children === 'string' ? children : undefined}
        className={cn(
          sidebarNavItemVariants({ active }),
          collapsed && 'justify-center gap-0 px-0',
          className
        )}
        {...props}
      >
        {icon}
        {/* asChild: o alvo do Slot precisa sempre existir (marcado via Slottable).
            Fora do asChild, o rótulo some quando colapsado (fica só o ícone). */}
        {asChild ? (
          <Slottable>{children}</Slottable>
        ) : (
          !collapsed && <span className="flex-1 truncate">{children}</span>
        )}
        {!collapsed && shortcut?.length ? (
          <Kbd keys={shortcut} className="ml-auto opacity-70 group-hover/nav-item:opacity-100" />
        ) : null}
      </Comp>
    )
  }
)
SidebarNavItem.displayName = 'SidebarNavItem'
