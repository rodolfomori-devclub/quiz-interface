import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarNav,
  SidebarNavItem,
  SidebarGroup,
  SidebarGroupLabel,
} from './sidebar'

describe('Sidebar', () => {
  it('renderiza a estrutura composta com landmark de navegação', () => {
    render(
      <Sidebar>
        <SidebarHeader>DevClub</SidebarHeader>
        <SidebarContent>
          <SidebarNav>
            <SidebarGroup>
              <SidebarGroupLabel>Escola</SidebarGroupLabel>
              <SidebarNavItem active>Aulas</SidebarNavItem>
              <SidebarNavItem shortcut={['⌘', 'K']}>Buscar</SidebarNavItem>
            </SidebarGroup>
          </SidebarNav>
        </SidebarContent>
        <SidebarFooter>Perfil</SidebarFooter>
      </Sidebar>
    )
    expect(screen.getByRole('navigation')).toBeInTheDocument()
    expect(screen.getByText('Escola')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Aulas' })).toHaveAttribute('aria-current', 'page')
    expect(screen.getByText('Buscar')).toBeInTheDocument()
  })

  it('esconde rótulo de grupo quando colapsado', () => {
    render(
      <Sidebar collapsed>
        <SidebarNav>
          <SidebarGroup>
            <SidebarGroupLabel>Escola</SidebarGroupLabel>
            <SidebarNavItem>Aulas</SidebarNavItem>
          </SidebarGroup>
        </SidebarNav>
      </Sidebar>
    )
    expect(screen.queryByText('Escola')).not.toBeInTheDocument()
  })

  it('compõe o item via asChild como link', () => {
    render(
      <SidebarNavItem asChild>
        <a href="/aulas">Aulas</a>
      </SidebarNavItem>
    )
    const link = screen.getByRole('link', { name: 'Aulas' })
    expect(link).toHaveAttribute('href', '/aulas')
    expect(link).toHaveAttribute('data-slot', 'sidebar-nav-item')
  })
})
