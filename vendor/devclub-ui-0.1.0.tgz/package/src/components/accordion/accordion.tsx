import * as React from 'react'
import { Accordion as AccordionPrimitive } from 'radix-ui'
import { ChevronDown } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * Accordion — seções expansíveis acessíveis (radix). Chevron rotaciona ao abrir
 * e o conteúdo anima a altura usando a CSS var --radix-accordion-content-height.
 */

// Keyframes de altura injetadas uma única vez (a var do radix não existe em
// tempo de config do Tailwind, então declaramos a animação aqui).
const KEYFRAMES = `
@keyframes devclub-accordion-down {
  from { height: 0 }
  to { height: var(--radix-accordion-content-height) }
}
@keyframes devclub-accordion-up {
  from { height: var(--radix-accordion-content-height) }
  to { height: 0 }
}`

if (typeof document !== 'undefined') {
  const id = 'devclub-accordion-keyframes'
  if (!document.getElementById(id)) {
    const style = document.createElement('style')
    style.id = id
    style.textContent = KEYFRAMES
    document.head.appendChild(style)
  }
}

export const Accordion = AccordionPrimitive.Root

export const AccordionItem = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Item>
>(({ className, ...props }, ref) => (
  <AccordionPrimitive.Item
    ref={ref}
    data-slot="accordion-item"
    className={cn('border-b border-line', className)}
    {...props}
  />
))
AccordionItem.displayName = 'AccordionItem'

export const AccordionTrigger = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Trigger>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Trigger>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Header className="flex" data-slot="accordion-header">
    <AccordionPrimitive.Trigger
      ref={ref}
      data-slot="accordion-trigger"
      className={cn(
        'flex flex-1 items-center justify-between gap-3 py-4 text-left',
        'text-copy font-medium text-fg',
        'transition-colors duration-[110ms] ease-productive hover:text-fg-brand',
        'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
        'disabled:pointer-events-none disabled:opacity-50',
        '[&[data-state=open]>svg]:rotate-180',
        className
      )}
      {...props}
    >
      {children}
      <ChevronDown
        aria-hidden
        className="size-4 shrink-0 text-fg-muted transition-transform duration-200 ease-productive motion-reduce:transition-none"
      />
    </AccordionPrimitive.Trigger>
  </AccordionPrimitive.Header>
))
AccordionTrigger.displayName = 'AccordionTrigger'

export const AccordionContent = React.forwardRef<
  React.ElementRef<typeof AccordionPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof AccordionPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <AccordionPrimitive.Content
    ref={ref}
    data-slot="accordion-content"
    className={cn(
      'overflow-hidden text-copy-sm text-fg-subtle',
      'data-[state=open]:animate-[devclub-accordion-down_200ms_ease-productive]',
      'data-[state=closed]:animate-[devclub-accordion-up_200ms_ease-productive]',
      'motion-reduce:animate-none'
    )}
    {...props}
  >
    <div className={cn('pb-4 pt-0', className)}>{children}</div>
  </AccordionPrimitive.Content>
))
AccordionContent.displayName = 'AccordionContent'
