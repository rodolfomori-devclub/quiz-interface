import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from './accordion'

describe('Accordion', () => {
  it('renderiza o trigger colapsado por padrão', () => {
    render(
      <Accordion type="single" collapsible>
        <AccordionItem value="item-1">
          <AccordionTrigger>O que é o DevClub?</AccordionTrigger>
          <AccordionContent>Uma comunidade de devs.</AccordionContent>
        </AccordionItem>
      </Accordion>
    )
    const trigger = screen.getByRole('button', { name: 'O que é o DevClub?' })
    expect(trigger).toBeInTheDocument()
    expect(trigger).toHaveAttribute('aria-expanded', 'false')
  })
})
