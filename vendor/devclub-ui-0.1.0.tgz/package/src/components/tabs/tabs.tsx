import * as React from 'react'
import { Tabs as TabsPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

/**
 * Tabs — navegação por abas acessível (radix). Variante `underline` (padrão)
 * com sublinhado verde animado no ativo; variante `pill` com fundo no ativo.
 */

type TabsVariant = 'underline' | 'pill'

// Propaga a variante da List para cada Trigger sem repetição manual.
const TabsVariantContext = React.createContext<TabsVariant>('underline')

export const Tabs = TabsPrimitive.Root

export const tabsListVariants = cva('inline-flex items-center', {
  variants: {
    variant: {
      underline: 'gap-1 border-b border-line',
      pill: 'gap-1 rounded-lg border border-line bg-subtle p-1',
    },
  },
  defaultVariants: { variant: 'underline' },
})

export interface TabsListProps
  extends React.ComponentPropsWithoutRef<typeof TabsPrimitive.List>,
    VariantProps<typeof tabsListVariants> {}

export const TabsList = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.List>,
  TabsListProps
>(({ className, variant = 'underline', ...props }, ref) => (
  <TabsVariantContext.Provider value={variant ?? 'underline'}>
    <TabsPrimitive.List
      ref={ref}
      data-slot="tabs-list"
      className={cn(tabsListVariants({ variant }), className)}
      {...props}
    />
  </TabsVariantContext.Provider>
))
TabsList.displayName = 'TabsList'

export const tabsTriggerVariants = cva(
  [
    'inline-flex items-center justify-center gap-2 whitespace-nowrap select-none',
    'font-mono font-medium text-label text-fg-subtle hover:text-fg',
    'transition-[color,background-color,border-color,box-shadow] duration-[110ms] ease-productive',
    'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
    'disabled:pointer-events-none disabled:opacity-50',
    '[&_svg]:size-4 [&_svg]:shrink-0',
  ],
  {
    variants: {
      variant: {
        underline:
          '-mb-px h-9 border-b-2 border-transparent px-3 data-[state=active]:border-brand data-[state=active]:text-fg',
        pill: 'h-8 rounded-md border border-transparent px-3 data-[state=active]:bg-component data-[state=active]:text-fg data-[state=active]:shadow-1',
      },
    },
    defaultVariants: { variant: 'underline' },
  }
)

export interface TabsTriggerProps
  extends React.ComponentPropsWithoutRef<typeof TabsPrimitive.Trigger> {}

export const TabsTrigger = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Trigger>,
  TabsTriggerProps
>(({ className, ...props }, ref) => {
  const variant = React.useContext(TabsVariantContext)
  return (
    <TabsPrimitive.Trigger
      ref={ref}
      data-slot="tabs-trigger"
      className={cn(tabsTriggerVariants({ variant }), className)}
      {...props}
    />
  )
})
TabsTrigger.displayName = 'TabsTrigger'

export const TabsContent = React.forwardRef<
  React.ElementRef<typeof TabsPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof TabsPrimitive.Content>
>(({ className, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    data-slot="tabs-content"
    className={cn(
      'mt-4 text-copy-sm text-fg',
      'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
      'data-[state=active]:animate-fade-in',
      className
    )}
    {...props}
  />
))
TabsContent.displayName = 'TabsContent'
