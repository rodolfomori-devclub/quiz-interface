import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Tabs, TabsList, TabsTrigger, TabsContent } from './tabs'

describe('Tabs', () => {
  it('renderiza tablist com triggers e o conteúdo ativo', () => {
    render(
      <Tabs defaultValue="codigo">
        <TabsList>
          <TabsTrigger value="codigo">Código</TabsTrigger>
          <TabsTrigger value="preview">Preview</TabsTrigger>
        </TabsList>
        <TabsContent value="codigo">Bloco de código</TabsContent>
        <TabsContent value="preview">Prévia</TabsContent>
      </Tabs>
    )
    expect(screen.getByRole('tablist')).toBeInTheDocument()
    const ativo = screen.getByRole('tab', { name: 'Código' })
    expect(ativo).toHaveAttribute('data-state', 'active')
    expect(screen.getByRole('tab', { name: 'Preview' })).toHaveAttribute('data-state', 'inactive')
    expect(screen.getByText('Bloco de código')).toBeInTheDocument()
  })
})
