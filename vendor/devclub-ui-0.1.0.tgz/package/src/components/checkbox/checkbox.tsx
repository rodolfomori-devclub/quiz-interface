import * as React from 'react'
import { Checkbox as CheckboxPrimitive } from 'radix-ui'
import { Check, Minus } from 'lucide-react'
import { cn } from '../../lib/cn'

export interface CheckboxProps
  extends React.ComponentPropsWithoutRef<typeof CheckboxPrimitive.Root> {}

/**
 * Checkbox — caixa de seleção quadrada. Marcado = verde da marca.
 * Suporta estado indeterminate (`checked="indeterminate"`, ícone Minus).
 */
export const Checkbox = React.forwardRef<
  React.ElementRef<typeof CheckboxPrimitive.Root>,
  CheckboxProps
>(({ className, ...props }, ref) => (
  <CheckboxPrimitive.Root
    ref={ref}
    data-slot="checkbox"
    className={cn(
      'peer inline-flex size-5 shrink-0 items-center justify-center rounded-sm border border-line bg-component text-on-brand',
      'transition-[background-color,border-color,box-shadow] duration-[110ms] ease-productive',
      'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
      'hover:border-line-strong',
      'disabled:cursor-not-allowed disabled:opacity-50',
      'data-[state=checked]:border-transparent data-[state=checked]:bg-brand',
      'data-[state=indeterminate]:border-transparent data-[state=indeterminate]:bg-brand',
      className
    )}
    {...props}
  >
    <CheckboxPrimitive.Indicator
      data-slot="checkbox-indicator"
      className="flex items-center justify-center text-current"
    >
      {props.checked === 'indeterminate' ? (
        <Minus className="size-3.5" strokeWidth={3} aria-hidden />
      ) : (
        <Check className="size-3.5" strokeWidth={3} aria-hidden />
      )}
    </CheckboxPrimitive.Indicator>
  </CheckboxPrimitive.Root>
))
Checkbox.displayName = 'Checkbox'
