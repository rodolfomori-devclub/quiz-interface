import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Checkbox } from './checkbox'

describe('Checkbox', () => {
  it('renderiza com role checkbox', () => {
    render(<Checkbox aria-label="Aceito" />)
    expect(screen.getByRole('checkbox', { name: 'Aceito' })).toBeInTheDocument()
  })

  it('alterna ao clicar', async () => {
    const onCheckedChange = vi.fn()
    render(<Checkbox aria-label="Aceito" onCheckedChange={onCheckedChange} />)
    await userEvent.click(screen.getByRole('checkbox', { name: 'Aceito' }))
    expect(onCheckedChange).toHaveBeenCalledWith(true)
  })

  it('reflete estado desabilitado', () => {
    render(<Checkbox aria-label="Aceito" disabled />)
    expect(screen.getByRole('checkbox', { name: 'Aceito' })).toBeDisabled()
  })
})
