import * as React from 'react'
import { Popover as PopoverPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

/**
 * Popover — painel flutuante ancorado ao gatilho.
 * Superfície elevada por borda + sombra 2; entra com scale-in, sai com fade.
 * Motion-safe. Posicionamento e ordem de camadas ficam a cargo do radix.
 */
export const Popover = PopoverPrimitive.Root

export const PopoverTrigger = PopoverPrimitive.Trigger

export const PopoverAnchor = PopoverPrimitive.Anchor

export const PopoverClose = PopoverPrimitive.Close

export const PopoverContent = React.forwardRef<
  React.ElementRef<typeof PopoverPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof PopoverPrimitive.Content>
>(({ className, align = 'center', sideOffset = 8, ...props }, ref) => (
  <PopoverPrimitive.Portal>
    <PopoverPrimitive.Content
      ref={ref}
      data-slot="popover-content"
      align={align}
      sideOffset={sideOffset}
      className={cn(
        'z-50 w-72',
        'rounded-lg border border-line bg-elevated p-4 text-fg shadow-2',
        'motion-safe:animate-scale-in',
        'data-[state=closed]:animate-scale-in data-[state=closed]:fill-mode-forwards data-[state=closed]:[animation-direction:reverse]',
        className
      )}
      {...props}
    />
  </PopoverPrimitive.Portal>
))
PopoverContent.displayName = 'PopoverContent'
