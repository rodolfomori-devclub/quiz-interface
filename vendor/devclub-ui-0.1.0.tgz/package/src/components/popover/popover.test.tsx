import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Popover, PopoverTrigger, PopoverContent, PopoverClose } from './popover'

describe('Popover', () => {
  it('renderiza o trigger no estado fechado', () => {
    render(
      <Popover>
        <PopoverTrigger>Opções</PopoverTrigger>
        <PopoverContent>
          <PopoverClose>Fechar</PopoverClose>
        </PopoverContent>
      </Popover>
    )
    expect(screen.getByRole('button', { name: 'Opções' })).toBeInTheDocument()
  })

  it('exibe o conteúdo quando aberto por padrão', () => {
    render(
      <Popover defaultOpen>
        <PopoverTrigger>Opções</PopoverTrigger>
        <PopoverContent>Conteúdo flutuante</PopoverContent>
      </Popover>
    )
    expect(screen.getByText('Conteúdo flutuante')).toBeInTheDocument()
  })
})
