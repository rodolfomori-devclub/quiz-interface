import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Label } from './label'

describe('Label', () => {
  it('renderiza o texto', () => {
    render(<Label>E-mail</Label>)
    expect(screen.getByText('E-mail')).toBeInTheDocument()
  })

  it('mostra asterisco quando required', () => {
    render(<Label required>Senha</Label>)
    expect(screen.getByText('Senha').textContent).toContain('*')
  })

  it('associa via htmlFor', () => {
    render(<Label htmlFor="campo">Nome</Label>)
    expect(screen.getByText('Nome')).toHaveAttribute('for', 'campo')
  })
})
