import * as React from 'react'
import { Label as LabelPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

export interface LabelProps
  extends React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root> {
  /** Exibe o asterisco de obrigatório (text-error-fg). */
  required?: boolean
}

/**
 * Label — rótulo de campo de formulário. Herda estado `data-disabled` do
 * controle associado e mostra asterisco opcional quando `required`.
 */
export const Label = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  LabelProps
>(({ className, required = false, children, ...props }, ref) => (
  <LabelPrimitive.Root
    ref={ref}
    data-slot="label"
    className={cn(
      'inline-flex items-center gap-1 text-label font-medium text-fg select-none',
      'data-[disabled]:cursor-not-allowed data-[disabled]:opacity-50',
      className
    )}
    {...props}
  >
    {children}
    {required && (
      <span aria-hidden className="text-error-fg">
        *
      </span>
    )}
  </LabelPrimitive.Root>
))
Label.displayName = 'Label'
