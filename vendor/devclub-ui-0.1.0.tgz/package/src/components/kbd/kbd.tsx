import * as React from 'react'
import { cn } from '../../lib/cn'

export interface KbdProps extends React.HTMLAttributes<HTMLElement> {
  /** Teclas em sequência, ex: `keys={['⌘', 'K']}`. Alternativa a children. */
  keys?: string[]
}

/**
 * Kbd — keycap física para ensinar atalhos (identidade DevClub: escola que
 * ensina terminal e atalhos). Renderiza `keys` como teclas separadas.
 */
export const Kbd = React.forwardRef<HTMLElement, KbdProps>(
  ({ className, keys, children, ...props }, ref) => {
    if (keys?.length) {
      return (
        <span ref={ref} className={cn('inline-flex items-center gap-1', className)} {...props}>
          {keys.map((k, i) => (
            <kbd key={i} data-slot="kbd" className={kbdKeyClass}>
              {k}
            </kbd>
          ))}
        </span>
      )
    }
    return (
      <kbd ref={ref as React.Ref<HTMLElement>} data-slot="kbd" className={cn(kbdKeyClass, className)} {...props}>
        {children}
      </kbd>
    )
  }
)
Kbd.displayName = 'Kbd'

const kbdKeyClass = cn(
  'inline-flex min-w-6 h-6 items-center justify-center rounded-md px-1.5',
  'border border-line border-b-[3px] bg-component',
  'font-mono text-label-xs text-fg-subtle',
  'shadow-[inset_0_-1px_0_var(--dc-white-a2)]'
)
