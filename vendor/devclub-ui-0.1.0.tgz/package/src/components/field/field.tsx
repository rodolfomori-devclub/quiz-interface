import * as React from 'react'
import { Label as LabelPrimitive, Slot as SlotPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

const { Root: Slot } = SlotPrimitive

interface FieldContextValue {
  controlId: string
  errorId: string
  hintId: string
  invalid: boolean
  hasError: boolean
  hasHint: boolean
  setHasError: (v: boolean) => void
  setHasHint: (v: boolean) => void
}

const FieldContext = React.createContext<FieldContextValue | null>(null)

function useFieldContext(): FieldContextValue {
  const ctx = React.useContext(FieldContext)
  if (!ctx) {
    throw new Error('Subpartes de Field devem ser usadas dentro de <Field>.')
  }
  return ctx
}

export interface FieldProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Marca o campo como inválido (também é ligado automaticamente por `<FieldError>`). */
  invalid?: boolean
}

/**
 * Field — wrapper de formulário composto. Conecta label, controle, erro e dica
 * via `id`/`aria-describedby`/`aria-invalid` automaticamente (useId).
 * Composição: Field + FieldLabel + FieldControl + FieldError + FieldHint.
 */
export const Field = React.forwardRef<HTMLDivElement, FieldProps>(
  ({ className, invalid = false, children, ...props }, ref) => {
    const uid = React.useId()
    const [hasError, setHasError] = React.useState(false)
    const [hasHint, setHasHint] = React.useState(false)

    const value = React.useMemo<FieldContextValue>(
      () => ({
        controlId: `${uid}-control`,
        errorId: `${uid}-error`,
        hintId: `${uid}-hint`,
        invalid: invalid || hasError,
        hasError,
        hasHint,
        setHasError,
        setHasHint,
      }),
      [uid, invalid, hasError, hasHint]
    )

    return (
      <FieldContext.Provider value={value}>
        <div
          ref={ref}
          data-slot="field"
          className={cn('flex flex-col gap-1.5', className)}
          {...props}
        >
          {children}
        </div>
      </FieldContext.Provider>
    )
  }
)
Field.displayName = 'Field'

/** FieldLabel — rótulo do campo (usa o primitivo Label da radix, ligado ao controle). */
export const FieldLabel = React.forwardRef<
  React.ElementRef<typeof LabelPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof LabelPrimitive.Root>
>(({ className, ...props }, ref) => {
  const { controlId } = useFieldContext()
  return (
    <LabelPrimitive.Root
      ref={ref}
      data-slot="field-label"
      htmlFor={controlId}
      className={cn('select-none text-label font-medium text-fg', className)}
      {...props}
    />
  )
})
FieldLabel.displayName = 'FieldLabel'

/**
 * FieldControl — slot que injeta `id`, `aria-describedby` e `aria-invalid` no
 * controle filho (ex: `<FieldControl><Input /></FieldControl>`).
 */
export const FieldControl = React.forwardRef<
  HTMLElement,
  React.HTMLAttributes<HTMLElement>
>(({ ...props }, ref) => {
  const { controlId, errorId, hintId, invalid, hasError, hasHint } = useFieldContext()
  const describedBy =
    [hasHint ? hintId : null, hasError ? errorId : null].filter(Boolean).join(' ') || undefined
  return (
    <Slot
      ref={ref}
      id={controlId}
      data-slot="field-control"
      aria-describedby={describedBy}
      aria-invalid={invalid || undefined}
      {...props}
    />
  )
})
FieldControl.displayName = 'FieldControl'

/** FieldHint — texto de dica auxiliar em tom silencioso. */
export const FieldHint = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, children, ...props }, ref) => {
    const { hintId, setHasHint } = useFieldContext()
    const hasChildren = children != null && children !== false
    React.useEffect(() => {
      if (!hasChildren) return
      setHasHint(true)
      return () => setHasHint(false)
    }, [hasChildren, setHasHint])
    if (!hasChildren) return null
    return (
      <p
        ref={ref}
        id={hintId}
        data-slot="field-hint"
        className={cn('text-label-sm text-fg-muted', className)}
        {...props}
      >
        {children}
      </p>
    )
  }
)
FieldHint.displayName = 'FieldHint'

/** FieldError — mensagem de erro (role=alert) que também marca o campo como inválido. */
export const FieldError = React.forwardRef<HTMLParagraphElement, React.HTMLAttributes<HTMLParagraphElement>>(
  ({ className, children, ...props }, ref) => {
    const { errorId, setHasError } = useFieldContext()
    const hasChildren = children != null && children !== false
    React.useEffect(() => {
      if (!hasChildren) return
      setHasError(true)
      return () => setHasError(false)
    }, [hasChildren, setHasError])
    if (!hasChildren) return null
    return (
      <p
        ref={ref}
        id={errorId}
        role="alert"
        data-slot="field-error"
        className={cn('text-label-sm text-error-fg', className)}
        {...props}
      >
        {children}
      </p>
    )
  }
)
FieldError.displayName = 'FieldError'
