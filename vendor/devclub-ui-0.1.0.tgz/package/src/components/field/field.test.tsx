import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Field, FieldLabel, FieldControl, FieldError, FieldHint } from './field'
import { Input } from '../input/input'

describe('Field', () => {
  it('associa label ao controle e liga descrições/aria-invalid', () => {
    render(
      <Field>
        <FieldLabel>E-mail</FieldLabel>
        <FieldControl>
          <Input placeholder="voce@devclub.com" />
        </FieldControl>
        <FieldHint>Use seu e-mail de acesso.</FieldHint>
        <FieldError>E-mail inválido</FieldError>
      </Field>
    )

    // Label ligado ao controle (getByLabelText resolve htmlFor/id).
    const control = screen.getByLabelText('E-mail')
    expect(control).toBeInTheDocument()

    // Erro presente marca aria-invalid e entra no aria-describedby.
    const error = screen.getByRole('alert')
    expect(error).toHaveTextContent('E-mail inválido')
    expect(control).toHaveAttribute('aria-invalid', 'true')
    expect(control.getAttribute('aria-describedby')).toContain(error.id)
  })

  it('não marca inválido quando não há erro', () => {
    render(
      <Field>
        <FieldLabel>Nome</FieldLabel>
        <FieldControl>
          <Input />
        </FieldControl>
      </Field>
    )
    expect(screen.getByLabelText('Nome')).not.toHaveAttribute('aria-invalid')
    expect(screen.queryByRole('alert')).not.toBeInTheDocument()
  })
})
