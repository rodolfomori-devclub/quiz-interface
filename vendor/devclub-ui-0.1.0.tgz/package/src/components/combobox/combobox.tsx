import * as React from 'react'
import { Popover } from 'radix-ui'
import { Command } from 'cmdk'
import { Check, ChevronsUpDown, Search } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * Combobox — seletor com busca, construído com cmdk dentro de um Popover radix.
 * Trigger no estilo Select; conteúdo em superfície elevada (bg-elevated + borda).
 * Composição: Combobox + ComboboxTrigger + ComboboxContent + ComboboxInput +
 * ComboboxList + ComboboxEmpty + ComboboxGroup + ComboboxItem.
 */
export const Combobox = Popover.Root

export interface ComboboxTriggerProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {}

/** ComboboxTrigger — botão que abre o popover, no estilo de um Select. */
export const ComboboxTrigger = React.forwardRef<HTMLButtonElement, ComboboxTriggerProps>(
  ({ className, children, ...props }, ref) => (
    <Popover.Trigger asChild>
      <button
        ref={ref}
        type="button"
        role="combobox"
        data-slot="combobox-trigger"
        className={cn(
          'flex h-10 w-full items-center justify-between gap-2 rounded-md border border-line bg-component px-3',
          'text-copy-sm text-fg',
          'transition-[border-color,box-shadow] duration-[110ms] ease-productive',
          'outline-none hover:border-line-strong',
          'focus-visible:border-brand-line focus-visible:shadow-glow',
          'data-[state=open]:border-brand-line data-[state=open]:shadow-glow',
          'disabled:cursor-not-allowed disabled:opacity-50',
          '[&>span]:truncate',
          className
        )}
        {...props}
      >
        {children}
        <ChevronsUpDown className="size-4 shrink-0 text-fg-muted" aria-hidden />
      </button>
    </Popover.Trigger>
  )
)
ComboboxTrigger.displayName = 'ComboboxTrigger'

export interface ComboboxContentProps
  extends React.ComponentPropsWithoutRef<typeof Popover.Content> {}

/** ComboboxContent — painel flutuante elevado que envolve o Command (cmdk). */
export const ComboboxContent = React.forwardRef<
  React.ElementRef<typeof Popover.Content>,
  ComboboxContentProps
>(({ className, children, align = 'start', sideOffset = 6, ...props }, ref) => (
  <Popover.Portal>
    <Popover.Content
      ref={ref}
      align={align}
      sideOffset={sideOffset}
      data-slot="combobox-content"
      className={cn(
        'z-50 w-[var(--radix-popover-trigger-width)] overflow-hidden rounded-md border border-line bg-elevated shadow-2',
        'origin-[var(--radix-popover-content-transform-origin)]',
        'data-[state=open]:animate-scale-in motion-reduce:animate-none',
        className
      )}
      {...props}
    >
      <Command
        data-slot="combobox-command"
        className="flex flex-col overflow-hidden text-fg [&_[cmdk-input-wrapper]]:border-b [&_[cmdk-input-wrapper]]:border-line"
      >
        {children}
      </Command>
    </Popover.Content>
  </Popover.Portal>
))
ComboboxContent.displayName = 'ComboboxContent'

/** ComboboxInput — campo de busca (Command.Input) com ícone de lupa. */
export const ComboboxInput = React.forwardRef<
  React.ElementRef<typeof Command.Input>,
  React.ComponentPropsWithoutRef<typeof Command.Input>
>(({ className, ...props }, ref) => (
  <div
    data-slot="combobox-input-wrapper"
    className="flex items-center gap-2 border-b border-line px-3"
  >
    <Search className="size-4 shrink-0 text-fg-muted" aria-hidden />
    <Command.Input
      ref={ref}
      data-slot="combobox-input"
      className={cn(
        'flex h-10 w-full bg-transparent text-copy-sm text-fg outline-none',
        'placeholder:text-fg-muted disabled:cursor-not-allowed disabled:opacity-50',
        className
      )}
      {...props}
    />
  </div>
))
ComboboxInput.displayName = 'ComboboxInput'

/** ComboboxList — área rolável de resultados (Command.List). */
export const ComboboxList = React.forwardRef<
  React.ElementRef<typeof Command.List>,
  React.ComponentPropsWithoutRef<typeof Command.List>
>(({ className, ...props }, ref) => (
  <Command.List
    ref={ref}
    data-slot="combobox-list"
    className={cn('max-h-64 overflow-y-auto overflow-x-hidden p-1', className)}
    {...props}
  />
))
ComboboxList.displayName = 'ComboboxList'

/** ComboboxEmpty — estado vazio da busca (Command.Empty). */
export const ComboboxEmpty = React.forwardRef<
  React.ElementRef<typeof Command.Empty>,
  React.ComponentPropsWithoutRef<typeof Command.Empty>
>(({ className, children = 'Nada encontrado', ...props }, ref) => (
  <Command.Empty
    ref={ref}
    data-slot="combobox-empty"
    className={cn('py-6 text-center text-copy-sm text-fg-muted', className)}
    {...props}
  >
    {children}
  </Command.Empty>
))
ComboboxEmpty.displayName = 'ComboboxEmpty'

/** ComboboxGroup — agrupa itens sob um rótulo (Command.Group). */
export const ComboboxGroup = React.forwardRef<
  React.ElementRef<typeof Command.Group>,
  React.ComponentPropsWithoutRef<typeof Command.Group>
>(({ className, ...props }, ref) => (
  <Command.Group
    ref={ref}
    data-slot="combobox-group"
    className={cn(
      'overflow-hidden p-1 text-fg',
      '[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5',
      '[&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:text-label-xs [&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-caps [&_[cmdk-group-heading]]:text-fg-muted',
      className
    )}
    {...props}
  />
))
ComboboxGroup.displayName = 'ComboboxGroup'

export interface ComboboxItemProps
  extends React.ComponentPropsWithoutRef<typeof Command.Item> {
  /** Mostra o check de selecionado à direita quando `true`. */
  selected?: boolean
}

/** ComboboxItem — opção selecionável (Command.Item). Destaque verde ao navegar. */
export const ComboboxItem = React.forwardRef<
  React.ElementRef<typeof Command.Item>,
  ComboboxItemProps
>(({ className, children, selected, ...props }, ref) => (
  <Command.Item
    ref={ref}
    data-slot="combobox-item"
    className={cn(
      'relative flex cursor-pointer select-none items-center gap-2 rounded-sm px-2 py-1.5',
      'text-copy-sm text-fg outline-none',
      'data-[selected=true]:bg-component-hover data-[selected=true]:text-fg-brand',
      'data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50',
      className
    )}
    {...props}
  >
    <span className="flex-1 truncate">{children}</span>
    {selected && <Check className="size-4 shrink-0 text-fg-brand" aria-hidden />}
  </Command.Item>
))
ComboboxItem.displayName = 'ComboboxItem'
