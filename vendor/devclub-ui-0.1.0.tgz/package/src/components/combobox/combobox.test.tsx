import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Combobox,
  ComboboxTrigger,
  ComboboxContent,
  ComboboxInput,
  ComboboxList,
  ComboboxEmpty,
  ComboboxGroup,
  ComboboxItem,
} from './combobox'

describe('Combobox', () => {
  // Estado fechado: só o trigger renderiza (não abrimos o portal em jsdom).
  it('renderiza o trigger fechado', () => {
    render(
      <Combobox>
        <ComboboxTrigger>
          <span>Selecione uma linguagem</span>
        </ComboboxTrigger>
        <ComboboxContent>
          <ComboboxInput placeholder="Buscar..." />
          <ComboboxList>
            <ComboboxEmpty />
            <ComboboxGroup heading="Linguagens">
              <ComboboxItem value="ts">TypeScript</ComboboxItem>
              <ComboboxItem value="go">Go</ComboboxItem>
            </ComboboxGroup>
          </ComboboxList>
        </ComboboxContent>
      </Combobox>
    )

    // role=combobox não deriva nome acessível do conteúdo (ARIA: name-from-author),
    // então consultamos pelo role e checamos texto/estado.
    const trigger = screen.getByRole('combobox')
    expect(trigger).toHaveTextContent('Selecione uma linguagem')
    expect(trigger).toHaveAttribute('data-state', 'closed')

    // Conteúdo do portal permanece fechado.
    expect(screen.queryByPlaceholderText('Buscar...')).not.toBeInTheDocument()
  })
})
