import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

/**
 * Skeleton — placeholder de carregamento. Shimmer por gradiente que corre sobre
 * a superfície `bg-component`. Em `motion-reduce`, troca o brilho por um pulse
 * de opacidade (sem movimento horizontal).
 */
export const skeletonVariants = cva(
  [
    'block rounded-md bg-component',
    // Shimmer: faixa clara (surface-hover) correndo da esquerda p/ direita.
    // O keyframe `shimmer` anima background-position; por isso o size 200%.
    'bg-[linear-gradient(90deg,var(--color-component),var(--color-surface-hover),var(--color-component))]',
    'bg-[length:200%_100%] animate-shimmer',
    // Reduced-motion: sem varredura horizontal, apenas pulse de opacidade.
    'motion-reduce:animate-glow-pulse motion-reduce:bg-none motion-reduce:bg-component',
  ],
  {
    variants: {
      shape: {
        rect: 'rounded-md',
        text: 'rounded-sm h-[1em]',
        circle: 'rounded-full aspect-square',
      },
    },
    defaultVariants: { shape: 'rect' },
  }
)

export interface SkeletonProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof skeletonVariants> {}

export const Skeleton = React.forwardRef<HTMLDivElement, SkeletonProps>(
  ({ className, shape, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="skeleton"
      role="status"
      aria-busy="true"
      aria-live="polite"
      className={cn(skeletonVariants({ shape }), className)}
      {...props}
    />
  )
)
Skeleton.displayName = 'Skeleton'
