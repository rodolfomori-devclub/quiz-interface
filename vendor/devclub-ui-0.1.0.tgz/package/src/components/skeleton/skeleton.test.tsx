import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Skeleton } from './skeleton'

describe('Skeleton', () => {
  it('renderiza com status acessível', () => {
    render(<Skeleton className="h-4 w-32" />)
    const el = screen.getByRole('status')
    expect(el).toHaveAttribute('data-slot', 'skeleton')
    expect(el).toHaveAttribute('aria-busy', 'true')
  })

  it('aplica shape circle', () => {
    render(<Skeleton shape="circle" className="size-10" data-testid="sk" />)
    expect(screen.getByTestId('sk').className).toContain('rounded-full')
  })
})
