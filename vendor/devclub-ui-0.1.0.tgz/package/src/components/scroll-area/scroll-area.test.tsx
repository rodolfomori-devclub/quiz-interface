import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { ScrollArea } from './scroll-area'

describe('ScrollArea', () => {
  it('renderiza o conteúdo dentro do viewport', () => {
    render(
      <ScrollArea className="h-24 w-40">
        <p>Conteúdo rolável</p>
      </ScrollArea>
    )
    expect(screen.getByText('Conteúdo rolável')).toBeInTheDocument()
  })

  it('aplica o data-slot na raiz', () => {
    const { container } = render(
      <ScrollArea>
        <div>x</div>
      </ScrollArea>
    )
    expect(container.querySelector('[data-slot="scroll-area"]')).toBeInTheDocument()
  })
})
