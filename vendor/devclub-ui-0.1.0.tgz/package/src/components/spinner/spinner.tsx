import * as React from 'react'
import { cn } from '../../lib/cn'

export interface SpinnerProps extends React.SVGAttributes<SVGSVGElement> {
  /** Rótulo acessível (some visualmente). Default: "Carregando". */
  label?: string
}

/** Spinner — indicador de carregamento circular. Respeita reduced-motion. */
export const Spinner = React.forwardRef<SVGSVGElement, SpinnerProps>(
  ({ className, label = 'Carregando', ...props }, ref) => (
    <svg
      ref={ref}
      data-slot="spinner"
      role="status"
      aria-label={label}
      viewBox="0 0 24 24"
      fill="none"
      className={cn('size-5 animate-spin text-current motion-reduce:animate-none', className)}
      {...props}
    >
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.2" strokeWidth="2.5" />
      <path
        d="M21 12a9 9 0 0 0-9-9"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
    </svg>
  )
)
Spinner.displayName = 'Spinner'
