import * as React from 'react'
import { cn } from '../../lib/cn'

export interface EmptyStateProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title'> {
  /** Ícone exibido dentro do círculo neutro. */
  icon?: React.ReactNode
  /** Título curto do estado vazio. */
  title: React.ReactNode
  /** Descrição opcional de apoio. */
  description?: React.ReactNode
  /** Slot de ação (ex: um `<Button>`). */
  action?: React.ReactNode
}

/**
 * EmptyState — estado vazio centralizado. Ícone em círculo neutro, título em
 * text-h5 e descrição esmaecida; verde reservado ao botão de ação (CTA).
 */
export const EmptyState = React.forwardRef<HTMLDivElement, EmptyStateProps>(
  ({ className, icon, title, description, action, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="empty-state"
      className={cn(
        'flex flex-col items-center justify-center text-center',
        'px-6 py-12 gap-3',
        className
      )}
      {...props}
    >
      {icon && (
        <div
          data-slot="empty-state-icon"
          aria-hidden
          className={cn(
            'mb-1 flex size-12 items-center justify-center rounded-full',
            'bg-component text-fg-muted [&_svg]:size-6'
          )}
        >
          {icon}
        </div>
      )}
      <h3 data-slot="empty-state-title" className="text-h5 font-semibold text-fg">
        {title}
      </h3>
      {description && (
        <p
          data-slot="empty-state-description"
          className="max-w-sm text-copy-sm text-fg-subtle"
        >
          {description}
        </p>
      )}
      {action && (
        <div data-slot="empty-state-action" className="mt-2">
          {action}
        </div>
      )}
    </div>
  )
)
EmptyState.displayName = 'EmptyState'
