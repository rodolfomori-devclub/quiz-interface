import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { EmptyState } from './empty-state'

describe('EmptyState', () => {
  it('renderiza título, descrição e ação', () => {
    render(
      <EmptyState
        icon={<svg data-testid="icone" />}
        title="Nenhum projeto ainda"
        description="Crie seu primeiro projeto para começar."
        action={<button>Novo projeto</button>}
      />
    )
    expect(
      screen.getByRole('heading', { name: 'Nenhum projeto ainda' })
    ).toBeInTheDocument()
    expect(
      screen.getByText('Crie seu primeiro projeto para começar.')
    ).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Novo projeto' })).toBeInTheDocument()
  })

  it('renderiza apenas com título obrigatório', () => {
    render(<EmptyState title="Vazio" />)
    expect(screen.getByRole('heading', { name: 'Vazio' })).toBeInTheDocument()
  })
})
