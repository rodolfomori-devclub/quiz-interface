import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { IconButton } from './icon-button'

describe('IconButton', () => {
  it('expõe o label como aria-label', () => {
    render(<IconButton label="Fechar"><svg /></IconButton>)
    expect(screen.getByRole('button', { name: 'Fechar' })).toBeInTheDocument()
  })

  it('dispara onClick', async () => {
    const onClick = vi.fn()
    render(
      <IconButton label="Salvar" onClick={onClick}>
        <svg />
      </IconButton>
    )
    await userEvent.click(screen.getByRole('button', { name: 'Salvar' }))
    expect(onClick).toHaveBeenCalledOnce()
  })

  it('fica desabilitado quando loading', () => {
    render(
      <IconButton label="Enviando" loading>
        <svg />
      </IconButton>
    )
    const btn = screen.getByRole('button', { name: 'Enviando' })
    expect(btn).toBeDisabled()
    expect(btn).toHaveAttribute('aria-busy', 'true')
  })
})
