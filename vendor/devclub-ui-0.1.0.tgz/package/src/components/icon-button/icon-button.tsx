import * as React from 'react'
import { Slot as SlotPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'
import { buttonVariants } from '../button/button'
import { Spinner } from '../spinner/spinner'

const { Root: Slot, Slottable } = SlotPrimitive

/**
 * Dimensões quadradas do IconButton — mapeiam os tamanhos do Button
 * (sm/md/lg) para um alvo quadrado, reusando a mesma estética visual.
 */
export const iconButtonSizes = cva('', {
  variants: {
    size: {
      sm: 'size-8 [&_svg]:size-4',
      md: 'size-10 [&_svg]:size-5',
      lg: 'size-12 [&_svg]:size-5',
    },
  },
  defaultVariants: { size: 'md' },
})

export interface IconButtonProps
  extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'size'>,
    Pick<VariantProps<typeof buttonVariants>, 'variant'>,
    VariantProps<typeof iconButtonSizes> {
  /** Rótulo acessível obrigatório — vira `aria-label` (botão só-ícone). */
  label: string
  /** Renderiza no elemento filho (composição). */
  asChild?: boolean
  /** Mostra spinner e desabilita interação. */
  loading?: boolean
}

/**
 * IconButton — botão só-ícone. Reusa a estética do Button (variants/foco)
 * num alvo quadrado. `label` é obrigatório para acessibilidade.
 */
export const IconButton = React.forwardRef<HTMLButtonElement, IconButtonProps>(
  (
    {
      className,
      variant,
      size,
      label,
      asChild = false,
      loading = false,
      disabled,
      children,
      ...props
    },
    ref
  ) => {
    const Comp = asChild ? Slot : 'button'
    const isDisabled = disabled || loading
    const content = asChild ? <Slottable>{children}</Slottable> : children

    return (
      <Comp
        ref={ref}
        data-slot="icon-button"
        aria-label={label}
        className={cn(
          buttonVariants({ variant }),
          'p-0',
          iconButtonSizes({ size }),
          className
        )}
        disabled={asChild ? undefined : isDisabled}
        data-disabled={asChild && isDisabled ? '' : undefined}
        aria-busy={loading || undefined}
        {...props}
      >
        {loading ? <Spinner className="size-4" aria-hidden /> : content}
      </Comp>
    )
  }
)
IconButton.displayName = 'IconButton'
