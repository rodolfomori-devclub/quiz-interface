import * as React from 'react'
import { Dialog as SheetPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

/**
 * Sheet — painel deslizante ancorado a um lado da tela (drawer).
 * Reusa o primitivo Dialog do radix (foco/escape/portal), mas desliza a partir
 * de `side` (top/right/bottom/left) via CVA. Overlay com scrim borrado. Motion-safe.
 */
export const Sheet = SheetPrimitive.Root

export const SheetTrigger = SheetPrimitive.Trigger

export const SheetPortal = SheetPrimitive.Portal

export const SheetClose = SheetPrimitive.Close

export const SheetOverlay = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Overlay
    ref={ref}
    data-slot="sheet-overlay"
    className={cn(
      'fixed inset-0 z-50 bg-scrim backdrop-blur-sm',
      'motion-safe:animate-fade-in',
      'data-[state=closed]:animate-fade-in data-[state=closed]:fill-mode-forwards data-[state=closed]:[animation-direction:reverse]',
      className
    )}
    {...props}
  />
))
SheetOverlay.displayName = 'SheetOverlay'

export const sheetVariants = cva(
  [
    'fixed z-50 flex flex-col gap-4',
    'bg-overlay text-fg shadow-3 border-line',
    'transition-transform ease-emphasized duration-[240ms]',
    'motion-reduce:transition-none',
  ],
  {
    variants: {
      side: {
        top: 'inset-x-0 top-0 border-b rounded-b-xl data-[state=closed]:-translate-y-full',
        bottom:
          'inset-x-0 bottom-0 border-t rounded-t-xl data-[state=closed]:translate-y-full',
        left: 'inset-y-0 left-0 h-full w-3/4 max-w-sm border-r rounded-r-xl data-[state=closed]:-translate-x-full',
        right:
          'inset-y-0 right-0 h-full w-3/4 max-w-sm border-l rounded-l-xl data-[state=closed]:translate-x-full',
      },
    },
    defaultVariants: { side: 'right' },
  }
)

export interface SheetContentProps
  extends React.ComponentPropsWithoutRef<typeof SheetPrimitive.Content>,
    VariantProps<typeof sheetVariants> {
  /** Esconde o botão de fechar (X) no canto. */
  hideClose?: boolean
}

export const SheetContent = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Content>,
  SheetContentProps
>(({ className, children, side = 'right', hideClose = false, ...props }, ref) => (
  <SheetPortal>
    <SheetOverlay />
    <SheetPrimitive.Content
      ref={ref}
      data-slot="sheet-content"
      className={cn(sheetVariants({ side }), 'p-6', className)}
      {...props}
    >
      {children}
      {!hideClose && (
        <SheetPrimitive.Close
          data-slot="sheet-close"
          aria-label="Fechar"
          className={cn(
            'absolute right-4 top-4 inline-flex size-8 items-center justify-center',
            'rounded-md text-fg-muted',
            'transition-colors duration-[110ms] ease-productive',
            'hover:bg-component hover:text-fg',
            'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
            'disabled:pointer-events-none'
          )}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            aria-hidden
            className="size-4"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </SheetPrimitive.Close>
      )}
    </SheetPrimitive.Content>
  </SheetPortal>
))
SheetContent.displayName = 'SheetContent'

export const SheetHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div data-slot="sheet-header" className={cn('flex flex-col gap-1.5 pr-8', className)} {...props} />
)
SheetHeader.displayName = 'SheetHeader'

export const SheetFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    data-slot="sheet-footer"
    className={cn('mt-auto flex flex-col-reverse gap-2 sm:flex-row sm:justify-end', className)}
    {...props}
  />
)
SheetFooter.displayName = 'SheetFooter'

export const SheetTitle = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Title>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Title
    ref={ref}
    data-slot="sheet-title"
    className={cn('text-h5 font-semibold tracking-tight text-fg', className)}
    {...props}
  />
))
SheetTitle.displayName = 'SheetTitle'

export const SheetDescription = React.forwardRef<
  React.ElementRef<typeof SheetPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof SheetPrimitive.Description>
>(({ className, ...props }, ref) => (
  <SheetPrimitive.Description
    ref={ref}
    data-slot="sheet-description"
    className={cn('text-copy-sm text-fg-subtle', className)}
    {...props}
  />
))
SheetDescription.displayName = 'SheetDescription'
