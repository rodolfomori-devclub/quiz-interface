import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Sheet,
  SheetTrigger,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetFooter,
} from './sheet'

describe('Sheet', () => {
  it('renderiza o trigger no estado fechado', () => {
    render(
      <Sheet>
        <SheetTrigger>Abrir painel</SheetTrigger>
        <SheetContent side="left">
          <SheetHeader>
            <SheetTitle>Filtros</SheetTitle>
            <SheetDescription>Refine os resultados</SheetDescription>
          </SheetHeader>
          <SheetFooter>rodapé</SheetFooter>
        </SheetContent>
      </Sheet>
    )
    expect(screen.getByRole('button', { name: 'Abrir painel' })).toBeInTheDocument()
  })

  it('exibe o conteúdo deslizante quando aberto', () => {
    render(
      <Sheet defaultOpen>
        <SheetContent side="right">
          <SheetTitle>Menu</SheetTitle>
        </SheetContent>
      </Sheet>
    )
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    expect(screen.getByText('Menu')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Fechar' })).toBeInTheDocument()
  })
})
