import * as React from 'react'
import { Tooltip as TooltipPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

/**
 * Tooltip — dica curta ao passar o mouse/focar. Fundo escuro (navy-12) com texto
 * claro para contraste alto, no tom "terminal". Envolva a árvore em `TooltipProvider`
 * uma vez (ou por instância) para controlar delays.
 */
export const TooltipProvider = TooltipPrimitive.Provider

export const Tooltip = TooltipPrimitive.Root

export const TooltipTrigger = TooltipPrimitive.Trigger

export interface TooltipContentProps
  extends React.ComponentPropsWithoutRef<typeof TooltipPrimitive.Content> {
  /** Mostra a seta apontando p/ o gatilho. Default: true. */
  arrow?: boolean
}

/** Conteúdo do Tooltip — renderizado em portal, animado e motion-reduce-safe. */
export const TooltipContent = React.forwardRef<
  React.ElementRef<typeof TooltipPrimitive.Content>,
  TooltipContentProps
>(({ className, sideOffset = 6, arrow = true, children, ...props }, ref) => (
  <TooltipPrimitive.Portal>
    <TooltipPrimitive.Content
      ref={ref}
      data-slot="tooltip-content"
      sideOffset={sideOffset}
      className={cn(
        'z-50 max-w-xs rounded-md bg-navy-12 px-2 py-1',
        'text-label-xs font-medium text-canvas',
        'shadow-2 select-none',
        'animate-scale-in motion-reduce:animate-none',
        'origin-[var(--radix-tooltip-content-transform-origin)]',
        className
      )}
      {...props}
    >
      {children}
      {arrow && <TooltipPrimitive.Arrow className="fill-navy-12" width={11} height={5} />}
    </TooltipPrimitive.Content>
  </TooltipPrimitive.Portal>
))
TooltipContent.displayName = 'TooltipContent'
