import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from './tooltip'

describe('Tooltip', () => {
  // Estado fechado: só o gatilho está no DOM (não abrimos o portal em jsdom).
  it('renderiza o gatilho fechado', () => {
    render(
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger>Ajuda</TooltipTrigger>
          <TooltipContent>Dica útil</TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
    expect(screen.getByRole('button', { name: 'Ajuda' })).toBeInTheDocument()
    // Conteúdo em portal não está montado enquanto fechado.
    expect(screen.queryByText('Dica útil')).not.toBeInTheDocument()
  })
})
