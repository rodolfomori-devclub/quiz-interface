import * as React from 'react'
import { Check, Copy } from 'lucide-react'
import { cn } from '../../lib/cn'

export interface CodeBlockProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Código a exibir. */
  code: string
  /** Linguagem — mostra badge mono no header (ex: "bash", "tsx"). */
  language?: string
  /** Mostra números de linha à esquerda. */
  showLineNumbers?: boolean
  /** Título opcional no header (ex: nome do arquivo). */
  title?: string
}

/**
 * CodeBlock — bloco de código com moldura de terminal ("code well").
 * Header com traffic lights + título mono e botão Copiar; corpo em `font-mono`
 * com scroll horizontal. Destaca o prompt "$" em `text-code-fg-muted`. Sem syntax
 * highlight real — deixamos o gancho pronto para o futuro.
 */
export const CodeBlock = React.forwardRef<HTMLDivElement, CodeBlockProps>(
  ({ className, code, language, showLineNumbers = false, title, ...props }, ref) => {
    const [copiado, setCopiado] = React.useState(false)
    const timeoutRef = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

    React.useEffect(() => () => clearTimeout(timeoutRef.current), [])

    const copiar = React.useCallback(async () => {
      try {
        await navigator.clipboard.writeText(code)
        setCopiado(true)
        clearTimeout(timeoutRef.current)
        timeoutRef.current = setTimeout(() => setCopiado(false), 2000)
      } catch {
        // Clipboard indisponível (ex: contexto inseguro) — falha silenciosa.
      }
    }, [code])

    // Remove uma quebra de linha final para não render uma linha vazia extra.
    const linhas = React.useMemo(() => code.replace(/\n$/, '').split('\n'), [code])

    return (
      <div
        ref={ref}
        data-slot="code-block"
        className={cn('overflow-hidden rounded-lg border border-line bg-code', className)}
        {...props}
      >
        {/* Header: traffic lights + título + linguagem + copiar */}
        <div className="flex items-center gap-3 border-b border-line-subtle px-4 py-2.5">
          <div className="flex items-center gap-1.5" aria-hidden>
            <span className="size-3 rounded-full bg-error" />
            <span className="size-3 rounded-full bg-warning" />
            <span className="size-3 rounded-full bg-success" />
          </div>

          {title && (
            <span className="truncate font-mono text-label-xs text-code-fg-muted">{title}</span>
          )}

          <div className="ml-auto flex items-center gap-3">
            {language && (
              <span className="select-none font-mono text-label-xs uppercase tracking-wide text-code-fg-subtle">
                {language}
              </span>
            )}
            <button
              type="button"
              onClick={copiar}
              data-slot="code-block-copy"
              aria-label={copiado ? 'Copiado' : 'Copiar código'}
              className={cn(
                'inline-flex size-7 items-center justify-center rounded-md border border-transparent text-code-fg-muted',
                'transition-[color,background-color,border-color] duration-[110ms] ease-productive',
                'outline-none hover:bg-code-hover hover:text-code-fg focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
                copiado && 'text-brand'
              )}
            >
              {copiado ? (
                <Check className="size-4" aria-hidden />
              ) : (
                <Copy className="size-4" aria-hidden />
              )}
            </button>
          </div>
        </div>

        {/* Corpo com scroll horizontal */}
        <div className="overflow-x-auto">
          <pre className="min-w-full p-4 font-mono text-copy-sm leading-relaxed text-code-fg">
            <code className="block">
              {linhas.map((linha, i) => (
                <span key={i} className="flex whitespace-pre">
                  {showLineNumbers && (
                    <span
                      aria-hidden
                      className="mr-4 w-[2ch] shrink-0 select-none text-right text-code-fg-muted"
                    >
                      {i + 1}
                    </span>
                  )}
                  <span>{renderLinha(linha)}</span>
                </span>
              ))}
            </code>
          </pre>
        </div>
      </div>
    )
  }
)
CodeBlock.displayName = 'CodeBlock'

/** Realça o prompt "$" no início da linha em `text-code-fg-muted`. */
function renderLinha(linha: string): React.ReactNode {
  const match = linha.match(/^(\s*)(\$)(.*)$/)
  if (match) {
    return (
      <>
        {match[1]}
        <span className="select-none text-code-fg-muted">$</span>
        {match[3]}
      </>
    )
  }
  // Espaço não-quebrável mantém a altura de linhas vazias.
  return linha === '' ? ' ' : linha
}
