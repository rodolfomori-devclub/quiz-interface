import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { CodeBlock } from './code-block'

describe('CodeBlock', () => {
  it('renderiza o código e o título', () => {
    render(<CodeBlock title="deploy.sh" code={'$ npm run build'} />)
    expect(screen.getByText('deploy.sh')).toBeInTheDocument()
    // O "$" é destacado em um <span> separado, então buscamos pelo restante.
    expect(screen.getByText(/npm run build/)).toBeInTheDocument()
  })

  it('mostra a badge de linguagem', () => {
    render(<CodeBlock language="bash" code="ls -la" />)
    expect(screen.getByText('bash')).toBeInTheDocument()
  })

  it('expõe o botão de copiar acessível', () => {
    render(<CodeBlock code="echo oi" />)
    expect(screen.getByRole('button', { name: 'Copiar código' })).toBeInTheDocument()
  })

  it('renderiza números de linha quando pedido', () => {
    render(<CodeBlock showLineNumbers code={'linha1\nlinha2'} />)
    expect(screen.getByText('1')).toBeInTheDocument()
    expect(screen.getByText('2')).toBeInTheDocument()
  })
})
