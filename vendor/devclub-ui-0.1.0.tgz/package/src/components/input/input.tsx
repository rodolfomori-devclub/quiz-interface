import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

export const inputVariants = cva(
  [
    'flex w-full rounded-md border bg-component text-fg',
    'placeholder:text-fg-muted',
    'transition-[border-color,box-shadow] duration-[110ms] ease-productive',
    'outline-none focus-visible:border-brand-line focus-visible:shadow-glow',
    'disabled:cursor-not-allowed disabled:opacity-50',
    'file:border-0 file:bg-transparent file:text-label file:font-medium file:text-fg',
  ],
  {
    variants: {
      inputSize: {
        sm: 'h-8 px-2.5 text-label-sm',
        md: 'h-10 px-3 text-copy-sm',
        lg: 'h-12 px-4 text-copy',
      },
      invalid: {
        true: 'border-error-line focus-visible:border-error focus-visible:shadow-none',
        false: 'border-line',
      },
      mono: {
        true: 'font-mono',
        false: '',
      },
    },
    defaultVariants: { inputSize: 'md', invalid: false, mono: false },
  }
)

export interface InputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'>,
    VariantProps<typeof inputVariants> {}

/** Input — campo de texto. Foco ilumina a borda com o verde da marca. */
export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, inputSize, invalid, mono, type = 'text', ...props }, ref) => (
    <input
      ref={ref}
      type={type}
      data-slot="input"
      aria-invalid={invalid || undefined}
      className={cn(inputVariants({ inputSize, invalid, mono }), className)}
      {...props}
    />
  )
)
Input.displayName = 'Input'
