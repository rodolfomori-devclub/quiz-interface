import * as React from 'react'
import { RadioGroup as RadioGroupPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

/** RadioGroup — container de opções mutuamente exclusivas. */
export const RadioGroup = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Root>
>(({ className, ...props }, ref) => (
  <RadioGroupPrimitive.Root
    ref={ref}
    data-slot="radio-group"
    className={cn('grid gap-3', className)}
    {...props}
  />
))
RadioGroup.displayName = 'RadioGroup'

/**
 * RadioGroupItem — círculo selecionável. Selecionado = borda da marca
 * com dot verde central.
 */
export const RadioGroupItem = React.forwardRef<
  React.ElementRef<typeof RadioGroupPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof RadioGroupPrimitive.Item>
>(({ className, ...props }, ref) => (
  <RadioGroupPrimitive.Item
    ref={ref}
    data-slot="radio-group-item"
    className={cn(
      'inline-flex size-5 shrink-0 items-center justify-center rounded-full border border-line bg-component',
      'transition-[border-color,box-shadow] duration-[110ms] ease-productive',
      'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
      'hover:border-line-strong',
      'disabled:cursor-not-allowed disabled:opacity-50',
      'data-[state=checked]:border-brand',
      className
    )}
    {...props}
  >
    <RadioGroupPrimitive.Indicator
      data-slot="radio-group-indicator"
      className="flex items-center justify-center"
    >
      <span aria-hidden className="size-2 rounded-full bg-brand" />
    </RadioGroupPrimitive.Indicator>
  </RadioGroupPrimitive.Item>
))
RadioGroupItem.displayName = 'RadioGroupItem'
