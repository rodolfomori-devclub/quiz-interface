import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { RadioGroup, RadioGroupItem } from './radio-group'

describe('RadioGroup', () => {
  it('renderiza os itens como radios', () => {
    render(
      <RadioGroup defaultValue="a" aria-label="Plano">
        <RadioGroupItem value="a" aria-label="Anual" />
        <RadioGroupItem value="b" aria-label="Mensal" />
      </RadioGroup>
    )
    expect(screen.getByRole('radio', { name: 'Anual' })).toBeInTheDocument()
    expect(screen.getByRole('radio', { name: 'Mensal' })).toBeInTheDocument()
  })

  it('marca o valor default como checado', () => {
    render(
      <RadioGroup defaultValue="a" aria-label="Plano">
        <RadioGroupItem value="a" aria-label="Anual" />
        <RadioGroupItem value="b" aria-label="Mensal" />
      </RadioGroup>
    )
    expect(screen.getByRole('radio', { name: 'Anual' })).toBeChecked()
  })
})
