import * as React from 'react'
import { Command as CommandPrimitive } from 'cmdk'
import { Dialog } from 'radix-ui'
import { Search } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * Command — paleta de comandos ⌘K com estética terminal (mono, prompt "›").
 * Baseada em cmdk; filtragem/teclado acessíveis vêm do primitivo. Use dentro de
 * `CommandDialog` para o overlay ⌘K, ou embutida (inline) em qualquer superfície.
 */
export const Command = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive>
>(({ className, ...props }, ref) => (
  <CommandPrimitive
    ref={ref}
    data-slot="command"
    className={cn(
      'flex h-full w-full flex-col overflow-hidden rounded-md bg-elevated text-fg',
      className
    )}
    {...props}
  />
))
Command.displayName = CommandPrimitive.displayName

export interface CommandDialogProps
  extends React.ComponentPropsWithoutRef<typeof CommandPrimitive> {
  open?: boolean
  onOpenChange?: (open: boolean) => void
  /** Rótulo acessível do diálogo (some visualmente). */
  label?: string
}

/** CommandDialog — a paleta ⌘K flutuante, montada num Dialog do radix. */
export const CommandDialog = ({
  open,
  onOpenChange,
  label = 'Paleta de comandos',
  children,
  ...props
}: CommandDialogProps) => (
  <Dialog.Root open={open} onOpenChange={onOpenChange}>
    <Dialog.Portal>
      <Dialog.Overlay
        data-slot="command-overlay"
        className={cn(
          'fixed inset-0 z-50 bg-scrim',
          'animate-fade-in motion-reduce:animate-none'
        )}
      />
      <Dialog.Content
        data-slot="command-dialog"
        aria-label={label}
        className={cn(
          'fixed left-1/2 top-[15%] z-50 w-full max-w-[40rem] -translate-x-1/2 px-4',
          'animate-slide-up motion-reduce:animate-none',
          'outline-none'
        )}
      >
        <Dialog.Title className="sr-only">{label}</Dialog.Title>
        <div className="overflow-hidden rounded-lg border border-line bg-elevated shadow-3">
          <Command
            className={cn(
              '[&_[data-slot=command-group-heading]]:px-2 [&_[data-slot=command-group-heading]]:py-1.5',
              '[&_[data-slot=command-group]]:px-2',
              '[&_[data-slot=command-item]]:px-2 [&_[data-slot=command-item]]:py-2'
            )}
            {...props}
          >
            {children}
          </Command>
        </div>
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog.Root>
)
CommandDialog.displayName = 'CommandDialog'

/** CommandInput — campo de busca mono, com ícone e prompt "›" do terminal. */
export const CommandInput = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Input>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Input>
>(({ className, placeholder = 'Digite um comando ou busque…', ...props }, ref) => (
  <div
    data-slot="command-input-wrapper"
    className="flex items-center gap-2 border-b border-line px-3"
  >
    <Search aria-hidden className="size-4 shrink-0 text-fg-muted" />
    <span aria-hidden className="select-none font-mono text-copy text-fg-brand">
      ›
    </span>
    <CommandPrimitive.Input
      ref={ref}
      data-slot="command-input"
      placeholder={placeholder}
      className={cn(
        'flex h-11 w-full bg-transparent py-3 font-mono text-copy-sm text-fg outline-none',
        'placeholder:text-fg-muted disabled:cursor-not-allowed disabled:opacity-50',
        className
      )}
      {...props}
    />
  </div>
))
CommandInput.displayName = CommandPrimitive.Input.displayName

export const CommandList = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.List>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.List>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.List
    ref={ref}
    data-slot="command-list"
    className={cn('max-h-[20rem] overflow-y-auto overflow-x-hidden p-1', className)}
    {...props}
  />
))
CommandList.displayName = CommandPrimitive.List.displayName

export const CommandEmpty = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Empty>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Empty>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Empty
    ref={ref}
    data-slot="command-empty"
    className={cn('py-6 text-center font-mono text-copy-sm text-fg-muted', className)}
    {...props}
  />
))
CommandEmpty.displayName = CommandPrimitive.Empty.displayName

export const CommandGroup = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Group>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Group>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Group
    ref={ref}
    data-slot="command-group"
    className={cn(
      'overflow-hidden p-1 text-fg',
      '[&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5',
      '[&_[cmdk-group-heading]]:font-mono [&_[cmdk-group-heading]]:text-label-xs',
      '[&_[cmdk-group-heading]]:uppercase [&_[cmdk-group-heading]]:tracking-caps',
      '[&_[cmdk-group-heading]]:text-fg-muted',
      className
    )}
    {...props}
  />
))
CommandGroup.displayName = CommandPrimitive.Group.displayName

export const CommandSeparator = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Separator>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Separator>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Separator
    ref={ref}
    data-slot="command-separator"
    className={cn('-mx-1 my-1 h-px bg-line', className)}
    {...props}
  />
))
CommandSeparator.displayName = CommandPrimitive.Separator.displayName

export const CommandItem = React.forwardRef<
  React.ElementRef<typeof CommandPrimitive.Item>,
  React.ComponentPropsWithoutRef<typeof CommandPrimitive.Item>
>(({ className, ...props }, ref) => (
  <CommandPrimitive.Item
    ref={ref}
    data-slot="command-item"
    className={cn(
      'relative flex cursor-default select-none items-center gap-2 rounded-sm px-2 py-1.5',
      'text-copy-sm text-fg outline-none',
      'transition-colors duration-[110ms] ease-productive',
      'data-[selected=true]:bg-component-hover data-[selected=true]:text-fg',
      'data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50',
      '[&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 [&_svg]:text-fg-muted',
      className
    )}
    {...props}
  />
))
CommandItem.displayName = CommandPrimitive.Item.displayName

/** Atalho de teclado alinhado à direita do item, em mono e cor esmaecida. */
export const CommandShortcut = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLSpanElement>) => (
  <span
    data-slot="command-shortcut"
    className={cn('ml-auto font-mono text-label-xs tracking-wide text-fg-muted', className)}
    {...props}
  />
)
CommandShortcut.displayName = 'CommandShortcut'
