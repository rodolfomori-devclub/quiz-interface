import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Command,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandShortcut,
} from './command'

describe('Command', () => {
  it('renderiza input de busca e itens inline', () => {
    render(
      <Command>
        <CommandInput placeholder="Buscar comando" />
        <CommandList>
          <CommandEmpty>Nada encontrado.</CommandEmpty>
          <CommandGroup heading="Ações">
            <CommandItem>
              Novo arquivo
              <CommandShortcut>⌘N</CommandShortcut>
            </CommandItem>
            <CommandItem>Abrir projeto</CommandItem>
          </CommandGroup>
        </CommandList>
      </Command>
    )

    expect(screen.getByPlaceholderText('Buscar comando')).toBeInTheDocument()
    expect(screen.getByText('Novo arquivo')).toBeInTheDocument()
    expect(screen.getByText('Abrir projeto')).toBeInTheDocument()
    expect(screen.getByText('⌘N')).toBeInTheDocument()
  })
})
