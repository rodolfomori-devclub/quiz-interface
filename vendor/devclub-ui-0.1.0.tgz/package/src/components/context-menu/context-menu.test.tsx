import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
} from './context-menu'

describe('ContextMenu', () => {
  // Estado fechado: a área de gatilho é renderizada; o portal só monta ao
  // clicar com o botão direito — não abrimos aqui para evitar flakiness.
  it('renderiza a área de gatilho e mantém o menu fechado', () => {
    render(
      <ContextMenu>
        <ContextMenuTrigger>Clique direito aqui</ContextMenuTrigger>
        <ContextMenuContent>
          <ContextMenuItem>Copiar</ContextMenuItem>
          <ContextMenuSeparator />
          <ContextMenuItem>Colar</ContextMenuItem>
        </ContextMenuContent>
      </ContextMenu>
    )

    expect(screen.getByText('Clique direito aqui')).toBeInTheDocument()
    expect(screen.queryByText('Copiar')).not.toBeInTheDocument()
  })
})
