import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  InputOTP,
  InputOTPGroup,
  InputOTPSlot,
  InputOTPSeparator,
} from './input-otp'

describe('InputOTP', () => {
  it('renderiza o input e os slots', () => {
    const { container } = render(
      <InputOTP maxLength={6} aria-label="Código de verificação">
        <InputOTPGroup>
          <InputOTPSlot index={0} />
          <InputOTPSlot index={1} />
          <InputOTPSlot index={2} />
        </InputOTPGroup>
        <InputOTPSeparator />
        <InputOTPGroup>
          <InputOTPSlot index={3} />
          <InputOTPSlot index={4} />
          <InputOTPSlot index={5} />
        </InputOTPGroup>
      </InputOTP>
    )

    expect(screen.getByLabelText('Código de verificação')).toBeInTheDocument()
    expect(container.querySelectorAll('[data-slot="input-otp-slot"]')).toHaveLength(6)
    expect(container.querySelector('[data-slot="input-otp-separator"]')).toBeInTheDocument()
  })
})
