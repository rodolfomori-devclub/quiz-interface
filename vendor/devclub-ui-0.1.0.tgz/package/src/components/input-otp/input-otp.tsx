import * as React from 'react'
import { OTPInput, OTPInputContext } from 'input-otp'
import { Minus } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * InputOTP — entrada de código de verificação (OTP) em caixas mono.
 * Slot ativo ilumina com o verde da marca + caret piscando (motion-reduce safe).
 * Composição: InputOTP + InputOTPGroup + InputOTPSlot + InputOTPSeparator.
 */
export const InputOTP = React.forwardRef<
  React.ElementRef<typeof OTPInput>,
  React.ComponentPropsWithoutRef<typeof OTPInput>
>(({ className, containerClassName, ...props }, ref) => (
  <OTPInput
    ref={ref}
    data-slot="input-otp"
    containerClassName={cn(
      'flex items-center gap-2 has-[:disabled]:opacity-50',
      containerClassName
    )}
    className={cn('disabled:cursor-not-allowed', className)}
    {...props}
  />
))
InputOTP.displayName = 'InputOTP'

/** InputOTPGroup — agrupa um conjunto contíguo de slots. */
export const InputOTPGroup = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="input-otp-group"
      className={cn('flex items-center gap-2', className)}
      {...props}
    />
  )
)
InputOTPGroup.displayName = 'InputOTPGroup'

export interface InputOTPSlotProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Índice do dígito representado por esta caixa. */
  index: number
}

/** InputOTPSlot — caixa individual de um dígito. */
export const InputOTPSlot = React.forwardRef<HTMLDivElement, InputOTPSlotProps>(
  ({ index, className, ...props }, ref) => {
    const context = React.useContext(OTPInputContext)
    const slot = context?.slots[index]
    const char = slot?.char
    const hasFakeCaret = slot?.hasFakeCaret
    const isActive = slot?.isActive

    return (
      <div
        ref={ref}
        data-slot="input-otp-slot"
        data-active={isActive || undefined}
        className={cn(
          'relative flex size-10 items-center justify-center',
          'rounded-md border border-line bg-component font-mono text-copy text-fg',
          'transition-[border-color,box-shadow] duration-[110ms] ease-productive',
          'data-[active=true]:z-10 data-[active=true]:border-brand data-[active=true]:shadow-glow',
          className
        )}
        {...props}
      >
        {char}
        {hasFakeCaret && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="h-5 w-px animate-cursor-blink bg-fg-brand motion-reduce:animate-none" />
          </div>
        )}
      </div>
    )
  }
)
InputOTPSlot.displayName = 'InputOTPSlot'

/** InputOTPSeparator — divisor visual entre grupos de slots. */
export const InputOTPSeparator = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="input-otp-separator"
      role="separator"
      className={cn('flex items-center text-fg-muted', className)}
      {...props}
    >
      <Minus className="size-4" aria-hidden />
    </div>
  )
)
InputOTPSeparator.displayName = 'InputOTPSeparator'
