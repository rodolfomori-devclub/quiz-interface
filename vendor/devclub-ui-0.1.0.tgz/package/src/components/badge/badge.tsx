import * as React from 'react'
import { Slot as SlotPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

const { Root: Slot, Slottable } = SlotPrimitive

export const badgeVariants = cva(
  [
    /* Pixel Física: cantos quase retos + mono espaçada em caixa alta */
    'inline-flex items-center gap-1.5 rounded-sm border font-mono font-medium',
    'uppercase tracking-caps whitespace-nowrap [&_svg]:size-3 [&_svg]:shrink-0',
  ],
  {
    variants: {
      variant: {
        neutral: 'bg-component text-fg-subtle border-line',
        brand: 'bg-brand-subtle text-fg-brand border-brand-line',
        success: 'bg-success-bg text-success-fg border-success-line',
        info: 'bg-info-bg text-info-fg border-info-line',
        warning: 'bg-warning-bg text-warning-fg border-warning-line',
        error: 'bg-error-bg text-error-fg border-error-line',
        outline: 'bg-transparent text-fg-subtle border-line',
        solid: 'bg-brand text-on-brand border-transparent',
        /* roxo SÓ aqui: raro/premium */
        premium: 'bg-premium-bg text-premium-fg border-premium-line',
      },
      size: {
        sm: 'h-5 px-2 text-label-xs',
        md: 'h-6 px-2.5 text-label-xs',
      },
    },
    defaultVariants: { variant: 'neutral', size: 'md' },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof badgeVariants> {
  asChild?: boolean
  /** Ponto de status colorido antes do texto (ex: online, concluído). */
  dot?: boolean
}

/** Badge — rótulo compacto em mono (voz de marca). Use `dot` para status. */
export const Badge = React.forwardRef<HTMLSpanElement, BadgeProps>(
  ({ className, variant, size, asChild = false, dot = false, children, ...props }, ref) => {
    const Comp = asChild ? Slot : 'span'
    const label = asChild ? <Slottable>{children}</Slottable> : children
    return (
      <Comp
        ref={ref}
        data-slot="badge"
        className={cn(badgeVariants({ variant, size }), className)}
        {...props}
      >
        {dot && (
          <span
            aria-hidden
            className="size-1.5 rounded-full bg-current shadow-[0_0_6px_currentColor]"
          />
        )}
        {label}
      </Comp>
    )
  }
)
Badge.displayName = 'Badge'
