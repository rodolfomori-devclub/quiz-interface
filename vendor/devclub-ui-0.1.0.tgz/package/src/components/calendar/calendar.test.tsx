import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Calendar } from './calendar'

describe('Calendar', () => {
  it('renderiza a grade do mês com botões de navegação e dias', () => {
    render(<Calendar mode="single" defaultMonth={new Date(2026, 6, 1)} />)
    // A navegação e os dias renderizam como <button>.
    const botoes = screen.getAllByRole('button')
    expect(botoes.length).toBeGreaterThan(0)
    // Um dia do mês deve estar presente.
    expect(screen.getByText('15')).toBeInTheDocument()
  })
})
