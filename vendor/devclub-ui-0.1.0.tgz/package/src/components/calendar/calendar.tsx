import * as React from 'react'
import { DayPicker } from 'react-day-picker'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '../../lib/cn'

export type CalendarProps = React.ComponentProps<typeof DayPicker>

/**
 * Calendar — datepicker acessível sobre o `react-day-picker` v9.
 * Estilizado com o vocabulário DevClub: dia selecionado em verde da marca,
 * hoje com borda de marca, dias fora do mês esmaecidos. Repassa todas as
 * props do `DayPicker` (mode, selected, onSelect, disabled, etc.).
 */
export function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  ...props
}: CalendarProps) {
  return (
    <DayPicker
      showOutsideDays={showOutsideDays}
      data-slot="calendar"
      className={cn('p-3', className)}
      classNames={{
        months: 'flex flex-col sm:flex-row gap-4',
        month: 'flex flex-col gap-4',
        month_caption: 'flex justify-center items-center h-9 relative',
        caption_label: 'text-label font-mono font-medium text-fg',
        nav: 'flex items-center gap-1 absolute inset-x-0 top-0 justify-between',
        button_previous: cn(
          'inline-flex items-center justify-center size-8 rounded-md border border-line',
          'bg-transparent text-fg-subtle transition-colors duration-[110ms] ease-productive',
          'hover:bg-component hover:text-fg hover:border-line-strong disabled:opacity-40'
        ),
        button_next: cn(
          'inline-flex items-center justify-center size-8 rounded-md border border-line',
          'bg-transparent text-fg-subtle transition-colors duration-[110ms] ease-productive',
          'hover:bg-component hover:text-fg hover:border-line-strong disabled:opacity-40'
        ),
        month_grid: 'w-full border-collapse',
        weekdays: 'flex',
        weekday: 'w-9 text-fg-muted font-mono text-label-xs uppercase tracking-caps',
        week: 'flex w-full mt-1.5',
        day: 'relative size-9 p-0 text-center text-copy-sm',
        day_button: cn(
          'size-9 rounded-md font-normal text-fg tabular-nums transition-colors duration-[110ms] ease-productive',
          'hover:bg-component-hover focus-visible:outline-focus',
          'aria-selected:bg-brand aria-selected:text-on-brand aria-selected:hover:bg-brand-hover'
        ),
        selected: 'text-on-brand',
        today: 'rounded-md border border-brand-line',
        outside: 'text-fg-muted aria-selected:text-on-brand',
        disabled: 'text-fg-muted opacity-40',
        range_start: 'rounded-l-md',
        range_end: 'rounded-r-md',
        range_middle: 'aria-selected:bg-brand-subtle aria-selected:text-fg-brand',
        hidden: 'invisible',
        ...classNames,
      }}
      components={{
        Chevron: ({ orientation, className: chevClassName, ...chevProps }) => {
          const Icon = orientation === 'left' ? ChevronLeft : ChevronRight
          return <Icon className={cn('size-4', chevClassName)} {...chevProps} />
        },
      }}
      {...props}
    />
  )
}
Calendar.displayName = 'Calendar'
