import * as React from 'react'
import { Slot as SlotPrimitive } from 'radix-ui'
import { ChevronLeft, ChevronRight, MoreHorizontal } from 'lucide-react'
import { cn } from '../../lib/cn'
import { buttonVariants } from '../button/button'

const { Root: Slot } = SlotPrimitive

/**
 * Pagination — navegação paginada semântica (nav > ul > li). Reaproveita os
 * estilos do Button (outline/ghost); a página ativa usa a variante `outline`.
 */
export const Pagination = ({ className, ...props }: React.ComponentPropsWithoutRef<'nav'>) => (
  <nav
    data-slot="pagination"
    role="navigation"
    aria-label="Paginação"
    className={cn('mx-auto flex w-full justify-center', className)}
    {...props}
  />
)
Pagination.displayName = 'Pagination'

export const PaginationContent = React.forwardRef<
  HTMLUListElement,
  React.ComponentPropsWithoutRef<'ul'>
>(({ className, ...props }, ref) => (
  <ul
    ref={ref}
    data-slot="pagination-content"
    className={cn('flex flex-row items-center gap-1', className)}
    {...props}
  />
))
PaginationContent.displayName = 'PaginationContent'

export const PaginationItem = React.forwardRef<
  HTMLLIElement,
  React.ComponentPropsWithoutRef<'li'>
>(({ className, ...props }, ref) => (
  <li ref={ref} data-slot="pagination-item" className={cn('', className)} {...props} />
))
PaginationItem.displayName = 'PaginationItem'

export interface PaginationLinkProps extends React.ComponentPropsWithoutRef<'a'> {
  asChild?: boolean
  /** Marca a página atual (aria-current + destaque visual). */
  isActive?: boolean
  size?: 'sm' | 'md' | 'icon'
}

/** Link/botão de página. `isActive` usa a variante `outline`; inativo é `ghost`. */
export const PaginationLink = React.forwardRef<HTMLAnchorElement, PaginationLinkProps>(
  ({ className, asChild = false, isActive = false, size = 'icon', ...props }, ref) => {
    const Comp = asChild ? Slot : 'a'
    return (
      <Comp
        ref={ref}
        data-slot="pagination-link"
        aria-current={isActive ? 'page' : undefined}
        data-active={isActive || undefined}
        className={cn(
          buttonVariants({ variant: isActive ? 'outline' : 'ghost', size }),
          'font-mono cursor-pointer',
          isActive && 'border-brand-line text-fg-brand',
          className
        )}
        {...props}
      />
    )
  }
)
PaginationLink.displayName = 'PaginationLink'

export const PaginationPrevious = ({
  className,
  ...props
}: PaginationLinkProps) => (
  <PaginationLink
    aria-label="Ir para a página anterior"
    size="md"
    className={cn('gap-1 px-3', className)}
    {...props}
  >
    <ChevronLeft className="size-4" />
    <span>Anterior</span>
  </PaginationLink>
)
PaginationPrevious.displayName = 'PaginationPrevious'

export const PaginationNext = ({ className, ...props }: PaginationLinkProps) => (
  <PaginationLink
    aria-label="Ir para a próxima página"
    size="md"
    className={cn('gap-1 px-3', className)}
    {...props}
  >
    <span>Próxima</span>
    <ChevronRight className="size-4" />
  </PaginationLink>
)
PaginationNext.displayName = 'PaginationNext'

export const PaginationEllipsis = ({
  className,
  ...props
}: React.ComponentPropsWithoutRef<'span'>) => (
  <span
    data-slot="pagination-ellipsis"
    aria-hidden
    className={cn('flex size-10 items-center justify-center text-fg-muted', className)}
    {...props}
  >
    <MoreHorizontal className="size-4" />
    <span className="sr-only">Mais páginas</span>
  </span>
)
PaginationEllipsis.displayName = 'PaginationEllipsis'
