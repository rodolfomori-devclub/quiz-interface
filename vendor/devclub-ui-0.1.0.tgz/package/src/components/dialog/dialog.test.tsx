import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from './dialog'

describe('Dialog', () => {
  it('renderiza o trigger no estado fechado', () => {
    render(
      <Dialog>
        <DialogTrigger>Abrir</DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Título</DialogTitle>
            <DialogDescription>Descrição</DialogDescription>
          </DialogHeader>
          <DialogFooter>rodapé</DialogFooter>
        </DialogContent>
      </Dialog>
    )
    expect(screen.getByRole('button', { name: 'Abrir' })).toBeInTheDocument()
  })

  it('exibe o conteúdo quando aberto por padrão', () => {
    render(
      <Dialog defaultOpen>
        <DialogContent>
          <DialogTitle>Confirmar</DialogTitle>
        </DialogContent>
      </Dialog>
    )
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    expect(screen.getByText('Confirmar')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Fechar' })).toBeInTheDocument()
  })
})
