import * as React from 'react'
import { Dialog as DialogPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

/**
 * Dialog — modal centralizado ("terminal premium").
 * Superfície elevada por borda + sombra; overlay com scrim borrado.
 * Entrada anima com scale-in, saída faz fade (data-[state=closed]). Motion-safe.
 */
export const Dialog = DialogPrimitive.Root

export const DialogTrigger = DialogPrimitive.Trigger

export const DialogPortal = DialogPrimitive.Portal

export const DialogClose = DialogPrimitive.Close

export const DialogOverlay = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Overlay
    ref={ref}
    data-slot="dialog-overlay"
    className={cn(
      'fixed inset-0 z-50 bg-scrim backdrop-blur-sm',
      'motion-safe:animate-fade-in',
      'data-[state=closed]:animate-fade-in data-[state=closed]:fill-mode-forwards data-[state=closed]:[animation-direction:reverse]',
      className
    )}
    {...props}
  />
))
DialogOverlay.displayName = 'DialogOverlay'

export interface DialogContentProps
  extends React.ComponentPropsWithoutRef<typeof DialogPrimitive.Content> {
  /** Esconde o botão de fechar (X) no canto. */
  hideClose?: boolean
}

export const DialogContent = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Content>,
  DialogContentProps
>(({ className, children, hideClose = false, ...props }, ref) => (
  <DialogPortal>
    <DialogOverlay />
    <DialogPrimitive.Content
      ref={ref}
      data-slot="dialog-content"
      className={cn(
        'fixed left-1/2 top-1/2 z-50 -translate-x-1/2 -translate-y-1/2',
        'w-full max-w-lg',
        'flex flex-col gap-4',
        'rounded-xl border border-line bg-overlay p-6 text-fg shadow-3',
        'motion-safe:animate-scale-in',
        'data-[state=closed]:animate-scale-in data-[state=closed]:fill-mode-forwards data-[state=closed]:[animation-direction:reverse]',
        className
      )}
      {...props}
    >
      {children}
      {!hideClose && (
        <DialogPrimitive.Close
          data-slot="dialog-close"
          aria-label="Fechar"
          className={cn(
            'absolute right-4 top-4 inline-flex size-8 items-center justify-center',
            'rounded-md text-fg-muted',
            'transition-colors duration-[110ms] ease-productive',
            'hover:bg-component hover:text-fg',
            'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
            'disabled:pointer-events-none'
          )}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            aria-hidden
            className="size-4"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
          >
            <path d="M18 6 6 18M6 6l12 12" />
          </svg>
        </DialogPrimitive.Close>
      )}
    </DialogPrimitive.Content>
  </DialogPortal>
))
DialogContent.displayName = 'DialogContent'

export const DialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    data-slot="dialog-header"
    className={cn('flex flex-col gap-1.5 pr-8', className)}
    {...props}
  />
)
DialogHeader.displayName = 'DialogHeader'

export const DialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    data-slot="dialog-footer"
    className={cn('flex flex-col-reverse gap-2 sm:flex-row sm:justify-end', className)}
    {...props}
  />
)
DialogFooter.displayName = 'DialogFooter'

export const DialogTitle = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Title
    ref={ref}
    data-slot="dialog-title"
    className={cn('text-h5 font-semibold tracking-tight text-fg', className)}
    {...props}
  />
))
DialogTitle.displayName = 'DialogTitle'

export const DialogDescription = React.forwardRef<
  React.ElementRef<typeof DialogPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DialogPrimitive.Description
    ref={ref}
    data-slot="dialog-description"
    className={cn('text-copy-sm text-fg-subtle', className)}
    {...props}
  />
))
DialogDescription.displayName = 'DialogDescription'
