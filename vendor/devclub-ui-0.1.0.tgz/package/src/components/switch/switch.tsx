import * as React from 'react'
import { Switch as SwitchPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

export interface SwitchProps
  extends React.ComponentPropsWithoutRef<typeof SwitchPrimitive.Root> {}

/**
 * Switch — interruptor liga/desliga. Trilho neutro; ligado = verde da marca.
 * O thumb desliza com transição suave (respeita reduced-motion).
 */
export const Switch = React.forwardRef<
  React.ElementRef<typeof SwitchPrimitive.Root>,
  SwitchProps
>(({ className, ...props }, ref) => (
  <SwitchPrimitive.Root
    ref={ref}
    data-slot="switch"
    className={cn(
      'peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border border-transparent bg-component p-0.5',
      'transition-colors duration-[150ms] ease-productive',
      'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
      'disabled:cursor-not-allowed disabled:opacity-50',
      'data-[state=checked]:bg-brand',
      className
    )}
    {...props}
  >
    <SwitchPrimitive.Thumb
      data-slot="switch-thumb"
      className={cn(
        'pointer-events-none block size-5 rounded-full bg-fg shadow-1',
        'transition-transform duration-[150ms] ease-productive motion-reduce:transition-none',
        'translate-x-0 data-[state=checked]:translate-x-5',
        'data-[state=checked]:bg-on-brand'
      )}
    />
  </SwitchPrimitive.Root>
))
Switch.displayName = 'Switch'
