import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Switch } from './switch'

describe('Switch', () => {
  it('renderiza com role switch', () => {
    render(<Switch aria-label="Notificações" />)
    expect(screen.getByRole('switch', { name: 'Notificações' })).toBeInTheDocument()
  })

  it('alterna ao clicar', async () => {
    const onCheckedChange = vi.fn()
    render(<Switch aria-label="Notificações" onCheckedChange={onCheckedChange} />)
    await userEvent.click(screen.getByRole('switch', { name: 'Notificações' }))
    expect(onCheckedChange).toHaveBeenCalledWith(true)
  })

  it('reflete estado desabilitado', () => {
    render(<Switch aria-label="Notificações" disabled />)
    expect(screen.getByRole('switch', { name: 'Notificações' })).toBeDisabled()
  })
})
