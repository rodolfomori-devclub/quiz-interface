import * as React from 'react'
import { Avatar as AvatarPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

/**
 * Avatar — foto/iniciais do usuário em círculo. Fallback mono com iniciais
 * enquanto a imagem carrega ou falha. Use `AvatarGroup` para empilhar vários.
 */
export const avatarVariants = cva(
  'relative flex shrink-0 overflow-hidden rounded-full border border-line bg-component select-none',
  {
    variants: {
      size: {
        sm: 'size-8 text-label-xs',
        md: 'size-10 text-label-sm',
        lg: 'size-14 text-copy',
      },
    },
    defaultVariants: { size: 'md' },
  }
)

export interface AvatarProps
  extends React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Root>,
    VariantProps<typeof avatarVariants> {}

export const Avatar = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Root>,
  AvatarProps
>(({ className, size, ...props }, ref) => (
  <AvatarPrimitive.Root
    ref={ref}
    data-slot="avatar"
    className={cn(avatarVariants({ size }), className)}
    {...props}
  />
))
Avatar.displayName = 'Avatar'

/** Imagem do Avatar — some automaticamente se falhar, revelando o Fallback. */
export const AvatarImage = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Image>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Image>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Image
    ref={ref}
    data-slot="avatar-image"
    className={cn('aspect-square size-full object-cover', className)}
    {...props}
  />
))
AvatarImage.displayName = 'AvatarImage'

/** Fallback do Avatar — iniciais em mono sobre superfície neutra. */
export const AvatarFallback = React.forwardRef<
  React.ElementRef<typeof AvatarPrimitive.Fallback>,
  React.ComponentPropsWithoutRef<typeof AvatarPrimitive.Fallback>
>(({ className, ...props }, ref) => (
  <AvatarPrimitive.Fallback
    ref={ref}
    data-slot="avatar-fallback"
    className={cn(
      'flex size-full items-center justify-center',
      'bg-component font-mono font-medium uppercase text-fg-subtle',
      className
    )}
    {...props}
  />
))
AvatarFallback.displayName = 'AvatarFallback'

export interface AvatarGroupProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Máximo de avatares visíveis; o excedente vira um contador "+N". */
  max?: number
}

/**
 * AvatarGroup — empilha avatares com sobreposição e anel na cor do canvas
 * (para separar visualmente). Passe vários `<Avatar>` como children.
 */
export const AvatarGroup = React.forwardRef<HTMLDivElement, AvatarGroupProps>(
  ({ className, max, children, ...props }, ref) => {
    const items = React.Children.toArray(children)
    const visible = max ? items.slice(0, max) : items
    const overflow = max ? items.length - visible.length : 0

    return (
      <div
        ref={ref}
        data-slot="avatar-group"
        className={cn('flex items-center -space-x-2', className)}
        {...props}
      >
        {visible.map((child, i) =>
          React.isValidElement(child)
            ? React.cloneElement(child as React.ReactElement<{ className?: string }>, {
                key: i,
                className: cn('ring-2 ring-canvas', (child.props as { className?: string }).className),
              })
            : child
        )}
        {overflow > 0 && (
          <span
            data-slot="avatar-group-overflow"
            className={cn(
              'relative flex size-10 items-center justify-center rounded-full',
              'ring-2 ring-canvas border border-line bg-component',
              'font-mono text-label-xs font-medium text-fg-subtle'
            )}
          >
            +{overflow}
          </span>
        )}
      </div>
    )
  }
)
AvatarGroup.displayName = 'AvatarGroup'
