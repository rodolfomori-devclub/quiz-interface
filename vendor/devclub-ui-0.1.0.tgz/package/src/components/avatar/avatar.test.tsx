import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Avatar, AvatarFallback, AvatarImage, AvatarGroup } from './avatar'

describe('Avatar', () => {
  it('mostra o fallback com iniciais', () => {
    render(
      <Avatar>
        <AvatarImage src="/nao-existe.png" alt="Rodolfo" />
        <AvatarFallback>RM</AvatarFallback>
      </Avatar>
    )
    // Em jsdom a imagem não carrega, então o fallback aparece.
    expect(screen.getByText('RM')).toBeInTheDocument()
  })

  it('AvatarGroup mostra contador de excedentes com max', () => {
    render(
      <AvatarGroup max={2}>
        <Avatar>
          <AvatarFallback>A</AvatarFallback>
        </Avatar>
        <Avatar>
          <AvatarFallback>B</AvatarFallback>
        </Avatar>
        <Avatar>
          <AvatarFallback>C</AvatarFallback>
        </Avatar>
      </AvatarGroup>
    )
    expect(screen.getByText('+1')).toBeInTheDocument()
  })
})
