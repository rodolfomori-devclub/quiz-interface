import * as React from 'react'
import { cn } from '../../lib/cn'

/**
 * TerminalWindow — moldura reutilizável de janela de terminal, a assinatura
 * visual do DevClub. Componível: TerminalWindow + TerminalHeader + TerminalBody.
 */
export const TerminalWindow = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="terminal-window"
      className={cn('overflow-hidden rounded-xl border border-line bg-code shadow-3', className)}
      {...props}
    />
  )
)
TerminalWindow.displayName = 'TerminalWindow'

export interface TerminalHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Título mono opcional exibido ao lado dos traffic lights. */
  title?: string
}

/** TerminalHeader — barra superior com traffic lights e título mono opcional. */
export const TerminalHeader = React.forwardRef<HTMLDivElement, TerminalHeaderProps>(
  ({ className, title, children, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="terminal-header"
      className={cn(
        'flex items-center gap-3 border-b border-line-subtle px-4 py-2.5',
        className
      )}
      {...props}
    >
      <div className="flex items-center gap-1.5" aria-hidden>
        <span className="size-3 rounded-full bg-error" />
        <span className="size-3 rounded-full bg-warning" />
        <span className="size-3 rounded-full bg-success" />
      </div>
      {title && <span className="truncate font-mono text-label-xs text-code-fg-muted">{title}</span>}
      {children}
    </div>
  )
)
TerminalHeader.displayName = 'TerminalHeader'

/** TerminalBody — área de conteúdo em `font-mono`. */
export const TerminalBody = React.forwardRef<HTMLDivElement, React.HTMLAttributes<HTMLDivElement>>(
  ({ className, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="terminal-body"
      className={cn('p-4 font-mono text-copy-sm leading-relaxed text-code-fg', className)}
      {...props}
    />
  )
)
TerminalBody.displayName = 'TerminalBody'
