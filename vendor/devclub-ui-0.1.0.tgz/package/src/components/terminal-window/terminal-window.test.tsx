import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { TerminalWindow, TerminalHeader, TerminalBody } from './terminal-window'

describe('TerminalWindow', () => {
  it('compõe header com título e corpo', () => {
    render(
      <TerminalWindow>
        <TerminalHeader title="~/devclub" />
        <TerminalBody>$ whoami</TerminalBody>
      </TerminalWindow>
    )
    expect(screen.getByText('~/devclub')).toBeInTheDocument()
    expect(screen.getByText('$ whoami')).toBeInTheDocument()
  })

  it('renderiza sem título', () => {
    render(
      <TerminalWindow>
        <TerminalHeader />
        <TerminalBody>output</TerminalBody>
      </TerminalWindow>
    )
    expect(screen.getByText('output')).toBeInTheDocument()
  })
})
