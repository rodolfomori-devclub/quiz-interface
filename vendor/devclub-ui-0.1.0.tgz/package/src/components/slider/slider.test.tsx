import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Slider } from './slider'

describe('Slider', () => {
  it('renderiza um thumb com role slider', () => {
    render(<Slider defaultValue={[50]} aria-label="Volume" />)
    const thumbs = screen.getAllByRole('slider')
    expect(thumbs).toHaveLength(1)
    expect(thumbs[0]).toHaveAttribute('aria-valuenow', '50')
  })

  it('renderiza múltiplos thumbs (faixa)', () => {
    render(<Slider defaultValue={[20, 80]} aria-label="Faixa" />)
    expect(screen.getAllByRole('slider')).toHaveLength(2)
  })
})
