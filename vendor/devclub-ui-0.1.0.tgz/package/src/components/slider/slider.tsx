import * as React from 'react'
import { Slider as SliderPrimitive } from 'radix-ui'
import { cn } from '../../lib/cn'

/**
 * Slider — controle de faixa acessível (Radix Slider).
 * Trilho neutro (bg-component); Range verde da marca (bg-brand); Thumb branco
 * com anel verde que ganha shadow-glow no foco. Suporta múltiplos thumbs
 * (passe `value`/`defaultValue` com mais de um número).
 */
export const Slider = React.forwardRef<
  React.ElementRef<typeof SliderPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof SliderPrimitive.Root>
>(({ className, value, defaultValue, ...props }, ref) => {
  // Um Thumb por valor da faixa (suporta range com múltiplos thumbs).
  const thumbCount = React.useMemo(() => {
    const source = value ?? defaultValue
    return Array.isArray(source) ? source.length : 1
  }, [value, defaultValue])

  return (
    <SliderPrimitive.Root
      ref={ref}
      data-slot="slider"
      value={value}
      defaultValue={defaultValue}
      className={cn(
        'relative flex w-full touch-none select-none items-center',
        'data-[orientation=vertical]:h-full data-[orientation=vertical]:min-h-44 data-[orientation=vertical]:w-auto data-[orientation=vertical]:flex-col',
        className
      )}
      {...props}
    >
      <SliderPrimitive.Track
        data-slot="slider-track"
        className={cn(
          'relative h-1.5 w-full grow overflow-hidden rounded-full bg-component',
          'data-[orientation=vertical]:h-full data-[orientation=vertical]:w-1.5'
        )}
      >
        <SliderPrimitive.Range
          data-slot="slider-range"
          className="absolute h-full rounded-full bg-brand data-[orientation=vertical]:w-full"
        />
      </SliderPrimitive.Track>
      {Array.from({ length: thumbCount }, (_, i) => (
        <SliderPrimitive.Thumb
          key={i}
          data-slot="slider-thumb"
          className={cn(
            'block size-4 rounded-full border-2 border-brand bg-fg shadow-1',
            'transition-[box-shadow] duration-[110ms] ease-productive',
            'outline-none hover:shadow-glow focus-visible:shadow-glow',
            'disabled:pointer-events-none disabled:opacity-50'
          )}
        />
      ))}
    </SliderPrimitive.Root>
  )
})
Slider.displayName = 'Slider'
