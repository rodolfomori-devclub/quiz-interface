import * as React from 'react'
import { X } from 'lucide-react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

export const tagVariants = cva(
  [
    'inline-flex items-center gap-1.5 rounded-full border font-mono font-medium',
    'whitespace-nowrap [&_svg]:size-3 [&_svg]:shrink-0',
  ],
  {
    variants: {
      variant: {
        neutral: 'bg-component text-fg-subtle border-line',
        brand: 'bg-brand-subtle text-fg-brand border-brand-line',
        success: 'bg-success-bg text-success-fg border-success-line',
        info: 'bg-info-bg text-info-fg border-info-line',
        warning: 'bg-warning-bg text-warning-fg border-warning-line',
        error: 'bg-error-bg text-error-fg border-error-line',
        outline: 'bg-transparent text-fg-subtle border-line',
      },
      size: {
        sm: 'h-5 pl-2 pr-2 text-label-xs',
        md: 'h-6 pl-2.5 pr-2.5 text-label-xs',
      },
    },
    defaultVariants: { variant: 'neutral', size: 'md' },
  }
)

export interface TagProps
  extends Omit<React.HTMLAttributes<HTMLSpanElement>, 'onRemoveCapture'>,
    VariantProps<typeof tagVariants> {
  /** Quando presente, mostra um botão X clicável para remover o chip. */
  onRemove?: () => void
  /** Rótulo acessível do botão de remoção. Default: "Remover". */
  removeLabel?: string
}

/** Tag — chip compacto em mono, opcionalmente removível via `onRemove`. */
export const Tag = React.forwardRef<HTMLSpanElement, TagProps>(
  ({ className, variant, size, onRemove, removeLabel = 'Remover', children, ...props }, ref) => (
    <span
      ref={ref}
      data-slot="tag"
      className={cn(tagVariants({ variant, size }), onRemove && 'pr-1', className)}
      {...props}
    >
      {children}
      {onRemove && (
        <button
          type="button"
          data-slot="tag-remove"
          aria-label={removeLabel}
          onClick={onRemove}
          className={cn(
            'inline-flex items-center justify-center rounded-full -mr-0.5 size-4',
            'text-current/70 hover:text-current hover:bg-current/15',
            'transition-colors duration-[110ms] ease-productive',
            'focus-visible:outline-focus'
          )}
        >
          <X aria-hidden />
        </button>
      )}
    </span>
  )
)
Tag.displayName = 'Tag'
