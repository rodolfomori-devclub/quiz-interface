import { describe, it, expect, vi } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Tag } from './tag'

describe('Tag', () => {
  it('renderiza o rótulo', () => {
    render(<Tag>typescript</Tag>)
    expect(screen.getByText('typescript')).toBeInTheDocument()
  })

  it('não mostra botão de remoção sem onRemove', () => {
    render(<Tag>react</Tag>)
    expect(screen.queryByRole('button')).not.toBeInTheDocument()
  })

  it('dispara onRemove ao clicar no X', async () => {
    const onRemove = vi.fn()
    render(<Tag onRemove={onRemove}>vitest</Tag>)
    const btn = screen.getByRole('button', { name: 'Remover' })
    await userEvent.click(btn)
    expect(onRemove).toHaveBeenCalledOnce()
  })
})
