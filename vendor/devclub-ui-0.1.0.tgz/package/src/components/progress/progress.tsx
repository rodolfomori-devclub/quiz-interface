import * as React from 'react'
import { Progress as ProgressPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

export const progressVariants = cva(
  'h-full w-full flex-1 bg-brand transition-[transform] duration-[300ms] ease-productive',
  {
    variants: {
      glow: {
        true: 'shadow-glow',
        false: '',
      },
    },
    defaultVariants: { glow: false },
  }
)

export interface ProgressProps
  extends React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root>,
    VariantProps<typeof progressVariants> {
  /** Valor atual (0–max). `null`/indefinido = indeterminado. */
  value?: number | null
  /**
   * Barra segmentada de arcade (estilo "Pixel Física"): renderiza N blocos em
   * vez de barra contínua — a assinatura do sistema para progresso de jornada.
   */
  segments?: number
}

/**
 * Progress — barra de progresso acessível (Radix Progress).
 * Contínua por padrão; com `segments`, vira a barra de vida de arcade
 * (blocos preenchidos), a assinatura do DevClub para trilhas e XP.
 * Variante `glow` acende o preenchido.
 */
export const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  ProgressProps
>(({ className, value, glow, segments, max = 100, ...props }, ref) => {
  const clamped = value == null ? null : Math.min(Math.max(value, 0), max)
  const pct = clamped == null ? 0 : (clamped / max) * 100

  if (segments && segments > 1) {
    const filled = Math.round((pct / 100) * segments)
    return (
      <ProgressPrimitive.Root
        ref={ref}
        data-slot="progress"
        value={clamped}
        max={max}
        className={cn('flex h-3 w-full gap-1', className)}
        {...props}
      >
        {Array.from({ length: segments }).map((_, i) => (
          <span
            key={i}
            data-filled={i < filled || undefined}
            className={cn(
              'h-full flex-1 rounded-[1px] bg-component transition-colors duration-[150ms] ease-productive',
              i < filled && 'bg-brand',
              i < filled && glow && 'shadow-glow'
            )}
          />
        ))}
      </ProgressPrimitive.Root>
    )
  }

  return (
    <ProgressPrimitive.Root
      ref={ref}
      data-slot="progress"
      value={clamped}
      max={max}
      className={cn('relative h-2 w-full overflow-hidden rounded-full bg-component', className)}
      {...props}
    >
      <ProgressPrimitive.Indicator
        data-slot="progress-indicator"
        className={cn(progressVariants({ glow }))}
        style={{ transform: `translateX(-${100 - pct}%)` }}
      />
    </ProgressPrimitive.Root>
  )
})
Progress.displayName = 'Progress'
