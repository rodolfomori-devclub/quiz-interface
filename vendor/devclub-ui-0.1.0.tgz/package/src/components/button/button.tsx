import * as React from 'react'
import { Slot as SlotPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'
import { Spinner } from '../spinner/spinner'

const { Root: Slot, Slottable } = SlotPrimitive

/**
 * Button — o componente canônico do DevClub.
 * Verde da marca só na variante `primary` (CTA); demais variantes usam superfícies
 * neutras. Foco visível verde vem do CSS base (:focus-visible global).
 */
/* Física de fliperama: sombra dura + deslocamento no aperto (estilo "Pixel
 * Física"). O clique desloca o botão sobre a própria sombra — tátil de verdade. */
const press =
  'active:translate-x-[3px] active:translate-y-[3px] active:shadow-none motion-reduce:active:translate-x-0 motion-reduce:active:translate-y-0'

export const buttonVariants = cva(
  [
    'inline-flex items-center justify-center gap-2 whitespace-nowrap select-none',
    'font-medium rounded-md border',
    'transition-[background-color,border-color,box-shadow,transform,color]',
    'duration-[110ms] ease-productive',
    'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
    'disabled:pointer-events-none disabled:opacity-50',
    '[&_svg]:pointer-events-none [&_svg]:shrink-0',
  ],
  {
    variants: {
      variant: {
        primary: `bg-brand text-on-brand border-transparent shadow-press-brand hover:bg-brand-hover ${press}`,
        secondary: `bg-surface text-fg border-2 border-fg shadow-press-neutral hover:bg-surface-hover ${press}`,
        outline: `bg-transparent text-fg border-line hover:bg-component hover:border-line-strong active:translate-y-px`,
        ghost: 'bg-transparent text-fg border-transparent hover:bg-component active:translate-y-px',
        link: 'bg-transparent text-fg-brand border-transparent underline-offset-4 hover:underline px-0 h-auto',
        destructive: `bg-error text-on-solid border-transparent shadow-press-error hover:brightness-110 ${press}`,
        terminal: `bg-code text-fg-brand border-brand-line font-mono hover:bg-brand-subtle shadow-press-brand ${press}`,
        /* roxo SÓ aqui: ação premium/rara */
        premium: `bg-premium-bg text-premium-fg border-2 border-premium shadow-press-premium hover:brightness-110 ${press}`,
      },
      size: {
        sm: 'h-8 px-3 text-label-sm [&_svg]:size-4',
        md: 'h-10 px-4 text-label [&_svg]:size-4',
        lg: 'h-12 px-6 text-copy [&_svg]:size-5',
        icon: 'size-10 p-0 [&_svg]:size-5',
      },
    },
    defaultVariants: {
      variant: 'primary',
      size: 'md',
    },
  }
)

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  /** Renderiza no elemento filho (composição), ex: `<Button asChild><a/></Button>`. */
  asChild?: boolean
  /** Mostra spinner e desabilita interação. */
  loading?: boolean
  /** Ícone antes do texto. */
  startIcon?: React.ReactNode
  /** Ícone depois do texto. */
  endIcon?: React.ReactNode
}

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      asChild = false,
      loading = false,
      startIcon,
      endIcon,
      disabled,
      children,
      ...props
    },
    ref
  ) => {
    const Comp = asChild ? Slot : 'button'
    const isDisabled = disabled || loading

    // Slottable marca qual filho é o elemento-alvo do Slot, permitindo
    // renderizar ícones/spinner ao redor sem quebrar a composição via asChild.
    const label = asChild ? <Slottable>{children}</Slottable> : children

    return (
      <Comp
        ref={ref}
        data-slot="button"
        className={cn(buttonVariants({ variant, size }), className)}
        disabled={asChild ? undefined : isDisabled}
        data-disabled={asChild && isDisabled ? '' : undefined}
        aria-busy={loading || undefined}
        {...props}
      >
        {loading ? <Spinner className="size-4" aria-hidden /> : startIcon}
        {label}
        {!loading && endIcon}
      </Comp>
    )
  }
)
Button.displayName = 'Button'
