import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Stepper, Step, StepLabel, StepDescription } from './stepper'

describe('Stepper', () => {
  it('renderiza a lista de passos com rótulos', () => {
    render(
      <Stepper>
        <Step status="completed">
          <StepLabel>Fundamentos</StepLabel>
        </Step>
        <Step status="current">
          <StepLabel>JavaScript</StepLabel>
          <StepDescription>Em andamento</StepDescription>
        </Step>
        <Step status="pending">
          <StepLabel>React</StepLabel>
        </Step>
      </Stepper>
    )
    expect(screen.getByRole('list')).toBeInTheDocument()
    expect(screen.getAllByRole('listitem')).toHaveLength(3)
    expect(screen.getByText('Fundamentos')).toBeInTheDocument()
    expect(screen.getByText('JavaScript')).toBeInTheDocument()
    expect(screen.getByText('Em andamento')).toBeInTheDocument()
  })

  it('numera automaticamente os passos não concluídos', () => {
    render(
      <Stepper>
        <Step status="current">
          <StepLabel>Um</StepLabel>
        </Step>
        <Step status="pending">
          <StepLabel>Dois</StepLabel>
        </Step>
      </Stepper>
    )
    expect(screen.getByText('1')).toBeInTheDocument()
    expect(screen.getByText('2')).toBeInTheDocument()
  })

  it('aceita orientação vertical', () => {
    render(
      <Stepper orientation="vertical">
        <Step status="pending">
          <StepLabel>Único</StepLabel>
        </Step>
      </Stepper>
    )
    expect(screen.getByRole('list')).toHaveAttribute('data-orientation', 'vertical')
  })
})
