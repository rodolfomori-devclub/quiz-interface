import * as React from 'react'
import { Check } from 'lucide-react'
import { cn } from '../../lib/cn'

type Orientation = 'horizontal' | 'vertical'
type StepStatus = 'completed' | 'current' | 'pending'

const StepperContext = React.createContext<{ orientation: Orientation }>({
  orientation: 'horizontal',
})

export interface StepperProps extends React.HTMLAttributes<HTMLOListElement> {
  /** Orientação da trilha. Default: `horizontal`. */
  orientation?: Orientation
}

/**
 * Stepper — trilha de progresso de jornada (ex: etapas de um curso).
 * Renderiza um `<ol>` de `Step`s; o conector do último passo é omitido.
 */
export const Stepper = React.forwardRef<HTMLOListElement, StepperProps>(
  ({ className, orientation = 'horizontal', children, ...props }, ref) => {
    // Injeta o índice em cada Step para numeração automática.
    const steps = React.Children.map(children, (child, index) =>
      React.isValidElement<StepProps>(child) ? React.cloneElement(child, { index }) : child
    )

    return (
      <StepperContext.Provider value={{ orientation }}>
        <ol
          ref={ref}
          data-slot="stepper"
          data-orientation={orientation}
          className={cn(
            'flex',
            orientation === 'horizontal' ? 'flex-row items-start' : 'flex-col',
            // Esconde o conector do último passo.
            '[&>li:last-child_[data-slot=step-connector]]:hidden',
            className
          )}
          {...props}
        >
          {steps}
        </ol>
      </StepperContext.Provider>
    )
  }
)
Stepper.displayName = 'Stepper'

export interface StepProps extends React.LiHTMLAttributes<HTMLLIElement> {
  /** Estado do passo. Default: `pending`. */
  status?: StepStatus
  /** Índice (injetado pelo Stepper) usado na numeração. */
  index?: number
}

/** Step — um passo da trilha (`<li>`), com marcador de estado e conector. */
export const Step = React.forwardRef<HTMLLIElement, StepProps>(
  ({ className, status = 'pending', index = 0, children, ...props }, ref) => {
    const { orientation } = React.useContext(StepperContext)
    const isHorizontal = orientation === 'horizontal'

    const marker = (
      <span
        aria-hidden
        data-slot="step-marker"
        className={cn(
          'flex size-8 shrink-0 items-center justify-center rounded-full border font-mono text-label-sm',
          status === 'completed' && 'border-transparent bg-brand text-on-brand',
          status === 'current' && 'border-brand bg-code text-fg-brand shadow-glow',
          status === 'pending' && 'border-line bg-transparent text-fg-muted'
        )}
      >
        {status === 'completed' ? <Check className="size-4" /> : index + 1}
      </span>
    )

    const connector = (
      <span
        aria-hidden
        data-slot="step-connector"
        className={cn(
          status === 'completed' ? 'border-brand' : 'border-line',
          isHorizontal ? 'mt-4 h-0 flex-1 border-t' : 'w-0 flex-1 border-l'
        )}
      />
    )

    if (isHorizontal) {
      return (
        <li
          ref={ref}
          data-slot="step"
          data-status={status}
          className={cn('flex flex-1 items-start gap-2 last:flex-none', className)}
          {...props}
        >
          <div className="flex flex-col items-center gap-2 text-center">
            {marker}
            {children}
          </div>
          {connector}
        </li>
      )
    }

    return (
      <li
        ref={ref}
        data-slot="step"
        data-status={status}
        className={cn('flex gap-4', className)}
        {...props}
      >
        <div className="flex flex-col items-center gap-2">
          {marker}
          {connector}
        </div>
        <div className="flex flex-col gap-1 pb-8">{children}</div>
      </li>
    )
  }
)
Step.displayName = 'Step'

/** StepLabel — título curto do passo. */
export const StepLabel = React.forwardRef<
  HTMLSpanElement,
  React.HTMLAttributes<HTMLSpanElement>
>(({ className, ...props }, ref) => (
  <span
    ref={ref}
    data-slot="step-label"
    className={cn('text-label font-medium text-fg', className)}
    {...props}
  />
))
StepLabel.displayName = 'StepLabel'

/** StepDescription — texto de apoio do passo. */
export const StepDescription = React.forwardRef<
  HTMLSpanElement,
  React.HTMLAttributes<HTMLSpanElement>
>(({ className, ...props }, ref) => (
  <span
    ref={ref}
    data-slot="step-description"
    className={cn('text-label-sm text-fg-subtle', className)}
    {...props}
  />
))
StepDescription.displayName = 'StepDescription'
