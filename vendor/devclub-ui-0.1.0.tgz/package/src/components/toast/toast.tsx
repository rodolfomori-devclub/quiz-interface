import * as React from 'react'
import { Toast as ToastPrimitive } from 'radix-ui'
import { cva, type VariantProps } from 'class-variance-authority'
import { X } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * Toast — notificação efêmera. Card elevado (bg-elevated + border-line + shadow-3)
 * que entra deslizando de baixo e sai por swipe. Envolva a app em `ToastProvider`
 * e monte um `ToastViewport` uma única vez; renderize `Toast` conforme necessário.
 */
export const ToastProvider = ToastPrimitive.Provider

/** Área fixa onde os toasts se empilham (canto inferior-direito por padrão). */
export const ToastViewport = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Viewport>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Viewport>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Viewport
    ref={ref}
    data-slot="toast-viewport"
    className={cn(
      'fixed bottom-0 right-0 z-50 m-0 flex w-full max-w-sm list-none flex-col gap-3 p-4',
      'outline-none',
      className
    )}
    {...props}
  />
))
ToastViewport.displayName = 'ToastViewport'

export const toastVariants = cva(
  [
    'group relative flex items-start gap-3 rounded-lg border p-4 pr-10',
    'bg-elevated shadow-3',
    // Entrada deslizando de baixo; saída instantânea (sem keyframe de saída no tema).
    'data-[state=open]:animate-slide-up motion-reduce:data-[state=open]:animate-fade-in',
    'data-[state=closed]:opacity-0 transition-opacity duration-[110ms] ease-exit',
    // Swipe para descartar (segue o dedo/cursor no eixo X).
    'data-[swipe=move]:translate-x-[var(--radix-toast-swipe-move-x)]',
    'data-[swipe=move]:transition-none',
    'data-[swipe=cancel]:translate-x-0 data-[swipe=cancel]:transition-[transform]',
    'data-[swipe=end]:opacity-0',
  ],
  {
    variants: {
      variant: {
        // Cor só no acento da borda esquerda — superfície permanece neutra.
        default: 'border-line',
        success: 'border-line border-l-2 border-l-success-line',
        error: 'border-line border-l-2 border-l-error-line',
      },
    },
    defaultVariants: { variant: 'default' },
  }
)

export interface ToastProps
  extends React.ComponentPropsWithoutRef<typeof ToastPrimitive.Root>,
    VariantProps<typeof toastVariants> {}

export const Toast = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Root>,
  ToastProps
>(({ className, variant, ...props }, ref) => (
  <ToastPrimitive.Root
    ref={ref}
    data-slot="toast"
    className={cn(toastVariants({ variant }), className)}
    {...props}
  />
))
Toast.displayName = 'Toast'

/** Título do toast — mono, voz de marca. */
export const ToastTitle = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Title>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Title
    ref={ref}
    data-slot="toast-title"
    className={cn('font-mono text-label font-semibold tracking-tight text-fg', className)}
    {...props}
  />
))
ToastTitle.displayName = 'ToastTitle'

/** Descrição do toast — texto de apoio. */
export const ToastDescription = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Description>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Description
    ref={ref}
    data-slot="toast-description"
    className={cn('text-copy-sm text-fg-subtle', className)}
    {...props}
  />
))
ToastDescription.displayName = 'ToastDescription'

/** Ação do toast — botão de destaque (ex: "Desfazer"). Estilo terminal em mono. */
export const ToastAction = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Action>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Action>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Action
    ref={ref}
    data-slot="toast-action"
    className={cn(
      'inline-flex h-8 shrink-0 items-center justify-center rounded-md px-3',
      'border border-brand-line bg-brand-subtle font-mono text-label-sm font-medium text-fg-brand',
      'transition-[background-color,box-shadow] duration-[110ms] ease-productive',
      'hover:bg-brand-subtle-hover hover:shadow-glow',
      'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
      className
    )}
    {...props}
  />
))
ToastAction.displayName = 'ToastAction'

/** Botão de fechar (X) — posicionado no canto superior-direito do card. */
export const ToastClose = React.forwardRef<
  React.ElementRef<typeof ToastPrimitive.Close>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitive.Close>
>(({ className, ...props }, ref) => (
  <ToastPrimitive.Close
    ref={ref}
    data-slot="toast-close"
    aria-label="Fechar"
    className={cn(
      'absolute right-2 top-2 inline-flex size-7 items-center justify-center rounded-md',
      'text-fg-muted transition-colors duration-[110ms] ease-productive',
      'hover:bg-component hover:text-fg',
      'outline-none focus-visible:outline-2 focus-visible:outline-focus focus-visible:outline-offset-2',
      '[&_svg]:size-4 [&_svg]:shrink-0',
      className
    )}
    {...props}
  >
    <X aria-hidden />
  </ToastPrimitive.Close>
))
ToastClose.displayName = 'ToastClose'
