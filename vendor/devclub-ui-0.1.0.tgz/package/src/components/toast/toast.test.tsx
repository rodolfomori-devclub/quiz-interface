import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Toast,
  ToastProvider,
  ToastViewport,
  ToastTitle,
  ToastDescription,
} from './toast'

describe('Toast', () => {
  // Estado fechado: o conteúdo do toast não é montado; só a viewport existe.
  it('renderiza a viewport e mantém o toast fechado', () => {
    render(
      <ToastProvider>
        <Toast open={false}>
          <ToastTitle>Salvo</ToastTitle>
          <ToastDescription>Suas alterações foram salvas.</ToastDescription>
        </Toast>
        <ToastViewport />
      </ToastProvider>
    )
    // Região da viewport presente (radix expõe role="region").
    expect(screen.getByRole('region')).toBeInTheDocument()
    // Fechado: título não está no DOM.
    expect(screen.queryByText('Salvo')).not.toBeInTheDocument()
  })

  it('mostra título e descrição quando aberto', () => {
    render(
      <ToastProvider>
        <Toast open>
          <ToastTitle>Salvo</ToastTitle>
          <ToastDescription>Suas alterações foram salvas.</ToastDescription>
        </Toast>
        <ToastViewport />
      </ToastProvider>
    )
    expect(screen.getByText('Salvo')).toBeInTheDocument()
    expect(screen.getByText('Suas alterações foram salvas.')).toBeInTheDocument()
  })
})
