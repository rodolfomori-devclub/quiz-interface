import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { StatCard } from './stat-card'

describe('StatCard', () => {
  it('renderiza label e valor', () => {
    render(<StatCard label="STREAK" value="42" />)
    expect(screen.getByText('STREAK')).toBeInTheDocument()
    expect(screen.getByText('42')).toBeInTheDocument()
  })

  it('mostra a tendência com o texto', () => {
    render(<StatCard label="XP" value="1280" trend={{ direction: 'up', value: '+12%' }} />)
    const trend = screen.getByText('+12%').closest('[data-slot="stat-trend"]')
    expect(trend).toBeInTheDocument()
    expect(trend).toHaveAttribute('data-direction', 'up')
  })

  it('aplica a variante glow', () => {
    render(<StatCard label="NÍVEL" value="7" variant="glow" />)
    expect(screen.getByText('7').closest('[data-slot="stat-card"]')).toHaveClass('shadow-glow')
  })
})
