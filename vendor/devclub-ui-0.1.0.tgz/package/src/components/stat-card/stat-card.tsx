import * as React from 'react'
import { ArrowDown, ArrowUp } from 'lucide-react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

export const statCardVariants = cva(
  'flex flex-col gap-2 rounded-xl border bg-surface p-5 text-fg',
  {
    variants: {
      variant: {
        default: 'border-line',
        // Destaque de gamificação (XP, streak): borda verde + brilho.
        glow: 'border-brand-line shadow-glow',
        // Roxo SÓ aqui: conquista rara/premium.
        premium: 'border-2 border-premium shadow-press-premium',
      },
    },
    defaultVariants: { variant: 'default' },
  }
)

/** Tendência exibida ao lado do valor (seta + variação percentual). */
export interface StatTrend {
  direction: 'up' | 'down'
  /** Texto já formatado, ex: "+12%". */
  value: string
}

export interface StatCardProps
  extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'>,
    VariantProps<typeof statCardVariants> {
  /** Rótulo em eyebrow mono (ex: "STREAK"). */
  label: string
  /** Valor principal — mono e tabular-nums para alinhar dígitos. */
  value: React.ReactNode
  /** Ícone no canto superior direito. */
  icon?: React.ReactNode
  /** Tendência opcional (verde p/ alta, vermelho p/ baixa). */
  trend?: StatTrend
}

/**
 * StatCard — card de métrica para gamificação. Números em `font-mono`
 * tabular; use `variant="glow"` para destacar XP/streak com borda verde.
 */
export const StatCard = React.forwardRef<HTMLDivElement, StatCardProps>(
  ({ className, variant, label, value, icon, trend, ...props }, ref) => (
    <div
      ref={ref}
      data-slot="stat-card"
      className={cn(statCardVariants({ variant }), className)}
      {...props}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="font-mono text-eyebrow uppercase tracking-caps text-fg-muted">
          {label}
        </span>
        {icon && <span className="text-fg-brand [&_svg]:size-5 [&_svg]:shrink-0">{icon}</span>}
      </div>

      <div className="flex items-end gap-2">
        <span className="font-pixel text-h3 tabular-nums leading-none text-fg">
          {value}
        </span>
        {trend && (
          <span
            data-slot="stat-trend"
            data-direction={trend.direction}
            className={cn(
              'inline-flex items-center gap-0.5 pb-0.5 font-mono text-label-sm tabular-nums',
              trend.direction === 'up' ? 'text-success-fg' : 'text-error-fg'
            )}
          >
            {trend.direction === 'up' ? (
              <ArrowUp className="size-3.5" aria-hidden />
            ) : (
              <ArrowDown className="size-3.5" aria-hidden />
            )}
            {trend.value}
          </span>
        )}
      </div>
    </div>
  )
)
StatCard.displayName = 'StatCard'
