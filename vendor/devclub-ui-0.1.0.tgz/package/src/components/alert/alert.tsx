import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { Info, CircleCheck, TriangleAlert, CircleX } from 'lucide-react'
import { cn } from '../../lib/cn'

/**
 * Alert — mensagem contextual em bloco. Composto: Alert + AlertTitle + AlertDescription.
 * Cada variante combina bg/borda/texto do estado com um ícone à esquerda.
 * Use `role="alert"` (via prop `role`) apenas para mensagens que precisam ser anunciadas.
 */
export const alertVariants = cva(
  [
    'relative w-full rounded-lg border p-4',
    'grid grid-cols-[auto_1fr] gap-x-3 gap-y-1',
    '[&>svg]:size-5 [&>svg]:shrink-0 [&>svg]:translate-y-px',
  ],
  {
    variants: {
      variant: {
        neutral: 'bg-subtle border-line text-fg [&>svg]:text-fg-subtle',
        brand: 'bg-brand-subtle border-brand-line text-fg [&>svg]:text-fg-brand',
        info: 'bg-info-bg border-info-line text-info-fg [&>svg]:text-info-fg',
        success: 'bg-success-bg border-success-line text-success-fg [&>svg]:text-success-fg',
        warning: 'bg-warning-bg border-warning-line text-warning-fg [&>svg]:text-warning-fg',
        error: 'bg-error-bg border-error-line text-error-fg [&>svg]:text-error-fg',
      },
    },
    defaultVariants: { variant: 'neutral' },
  }
)

// Ícone padrão por variante (lucide). `brand`/`neutral` usam Info.
const defaultIcon = {
  neutral: Info,
  brand: Info,
  info: Info,
  success: CircleCheck,
  warning: TriangleAlert,
  error: CircleX,
} as const

export interface AlertProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof alertVariants> {
  /** Ícone customizado à esquerda. `false` remove o ícone; ausente usa o padrão da variante. */
  icon?: React.ReactNode | false
}

export const Alert = React.forwardRef<HTMLDivElement, AlertProps>(
  ({ className, variant = 'neutral', icon, children, ...props }, ref) => {
    const Icon = defaultIcon[variant ?? 'neutral']
    const showIcon = icon !== false
    return (
      <div
        ref={ref}
        data-slot="alert"
        className={cn(alertVariants({ variant }), className)}
        {...props}
      >
        {showIcon && (icon ?? <Icon aria-hidden />)}
        <div className="col-start-2 grid gap-1">{children}</div>
      </div>
    )
  }
)
Alert.displayName = 'Alert'

/** Título do Alert — mono para reforçar a voz de marca. */
export const AlertTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    data-slot="alert-title"
    className={cn('font-mono text-label font-semibold tracking-tight', className)}
    {...props}
  />
))
AlertTitle.displayName = 'AlertTitle'

/** Descrição do Alert — texto de apoio, herda a cor do estado. */
export const AlertDescription = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="alert-description"
    className={cn('text-copy-sm opacity-90 [&_p]:leading-relaxed', className)}
    {...props}
  />
))
AlertDescription.displayName = 'AlertDescription'
