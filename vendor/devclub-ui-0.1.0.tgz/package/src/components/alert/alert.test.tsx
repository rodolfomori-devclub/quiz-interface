import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Alert, AlertTitle, AlertDescription } from './alert'

describe('Alert', () => {
  it('renderiza título e descrição', () => {
    render(
      <Alert variant="success">
        <AlertTitle>Deploy concluído</AlertTitle>
        <AlertDescription>Tudo certo na produção.</AlertDescription>
      </Alert>
    )
    expect(screen.getByText('Deploy concluído')).toBeInTheDocument()
    expect(screen.getByText('Tudo certo na produção.')).toBeInTheDocument()
  })

  it('anuncia como alerta quando role="alert"', () => {
    render(
      <Alert role="alert" variant="error">
        <AlertTitle>Falhou</AlertTitle>
      </Alert>
    )
    expect(screen.getByRole('alert')).toBeInTheDocument()
  })

  it('omite o ícone quando icon={false}', () => {
    const { container } = render(
      <Alert icon={false}>
        <AlertTitle>Sem ícone</AlertTitle>
      </Alert>
    )
    expect(container.querySelector('svg')).toBeNull()
  })
})
