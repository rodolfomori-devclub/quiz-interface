import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from './select'

describe('Select', () => {
  // Estado fechado: o portal não é aberto (evita flakiness em jsdom).
  it('renderiza o trigger com placeholder', () => {
    render(
      <Select>
        <SelectTrigger aria-label="Linguagem">
          <SelectValue placeholder="Escolha" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="ts">TypeScript</SelectItem>
          <SelectItem value="js">JavaScript</SelectItem>
        </SelectContent>
      </Select>
    )
    const trigger = screen.getByRole('combobox', { name: 'Linguagem' })
    expect(trigger).toBeInTheDocument()
    expect(screen.getByText('Escolha')).toBeInTheDocument()
  })
})
