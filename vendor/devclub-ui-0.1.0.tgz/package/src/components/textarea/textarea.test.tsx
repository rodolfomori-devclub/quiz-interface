import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { Textarea } from './textarea'

describe('Textarea', () => {
  it('renderiza um textbox', () => {
    render(<Textarea placeholder="Comentário" />)
    expect(screen.getByPlaceholderText('Comentário')).toBeInTheDocument()
  })

  it('aceita digitação', async () => {
    render(<Textarea aria-label="msg" />)
    const el = screen.getByRole('textbox', { name: 'msg' })
    await userEvent.type(el, 'olá')
    expect(el).toHaveValue('olá')
  })

  it('marca aria-invalid quando invalid', () => {
    render(<Textarea aria-label="msg" invalid />)
    expect(screen.getByRole('textbox', { name: 'msg' })).toHaveAttribute(
      'aria-invalid',
      'true'
    )
  })
})
