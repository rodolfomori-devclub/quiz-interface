import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

export const textareaVariants = cva(
  [
    'flex w-full rounded-md border bg-component text-fg',
    'placeholder:text-fg-muted',
    'transition-[border-color,box-shadow] duration-[110ms] ease-productive',
    'outline-none focus-visible:border-brand-line focus-visible:shadow-glow',
    'disabled:cursor-not-allowed disabled:opacity-50',
  ],
  {
    variants: {
      inputSize: {
        sm: 'min-h-16 px-2.5 py-2 text-label-sm',
        md: 'min-h-20 px-3 py-2.5 text-copy-sm',
        lg: 'min-h-24 px-4 py-3 text-copy',
      },
      invalid: {
        true: 'border-error-line focus-visible:border-error focus-visible:shadow-none',
        false: 'border-line',
      },
      mono: {
        true: 'font-mono',
        false: '',
      },
    },
    defaultVariants: { inputSize: 'md', invalid: false, mono: false },
  }
)

export interface TextareaProps
  extends React.TextareaHTMLAttributes<HTMLTextAreaElement>,
    VariantProps<typeof textareaVariants> {}

/** Textarea — campo de texto multilinha. Foco ilumina a borda com o verde da marca. */
export const Textarea = React.forwardRef<HTMLTextAreaElement, TextareaProps>(
  ({ className, inputSize, invalid, mono, ...props }, ref) => (
    <textarea
      ref={ref}
      data-slot="textarea"
      aria-invalid={invalid || undefined}
      className={cn(textareaVariants({ inputSize, invalid, mono }), className)}
      {...props}
    />
  )
)
Textarea.displayName = 'Textarea'
