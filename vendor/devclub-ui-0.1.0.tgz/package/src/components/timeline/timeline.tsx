import * as React from 'react'
import { cva, type VariantProps } from 'class-variance-authority'
import { cn } from '../../lib/cn'

/**
 * Timeline — composição vertical para histórico/jornada.
 * Estrutura: Timeline (ol) > TimelineItem (li com linha e dot) >
 * TimelineDot + TimelineContent (TimelineTitle, TimelineTime).
 */
export const Timeline = React.forwardRef<HTMLOListElement, React.HTMLAttributes<HTMLOListElement>>(
  ({ className, ...props }, ref) => (
    <ol ref={ref} data-slot="timeline" className={cn('flex flex-col', className)} {...props} />
  )
)
Timeline.displayName = 'Timeline'

export const TimelineItem = React.forwardRef<
  HTMLLIElement,
  React.LiHTMLAttributes<HTMLLIElement>
>(({ className, children, ...props }, ref) => (
  <li
    ref={ref}
    data-slot="timeline-item"
    className={cn(
      // Linha vertical: pseudo-elemento à esquerda, escondido no último item.
      'relative flex gap-3 pb-6 last:pb-0',
      "before:absolute before:left-[7px] before:top-4 before:bottom-0 before:w-px before:bg-line",
      'last:before:hidden',
      className
    )}
    {...props}
  >
    {children}
  </li>
))
TimelineItem.displayName = 'TimelineItem'

const timelineDotVariants = cva(
  [
    'relative z-10 mt-1 flex size-3.5 shrink-0 items-center justify-center rounded-full border-2',
  ],
  {
    variants: {
      status: {
        active: 'bg-brand border-brand shadow-glow',
        pending: 'bg-component border-line',
        done: 'bg-success border-success',
      },
    },
    defaultVariants: { status: 'pending' },
  }
)

export interface TimelineDotProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof timelineDotVariants> {}

/** TimelineDot — marcador do item. `active` em verde da marca, `pending` neutro. */
export const TimelineDot = React.forwardRef<HTMLSpanElement, TimelineDotProps>(
  ({ className, status, ...props }, ref) => (
    <span
      ref={ref}
      data-slot="timeline-dot"
      aria-hidden
      className={cn(timelineDotVariants({ status }), className)}
      {...props}
    />
  )
)
TimelineDot.displayName = 'TimelineDot'

export const TimelineContent = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement>
>(({ className, ...props }, ref) => (
  <div
    ref={ref}
    data-slot="timeline-content"
    className={cn('flex flex-col gap-1 pt-0.5', className)}
    {...props}
  />
))
TimelineContent.displayName = 'TimelineContent'

export const TimelineTitle = React.forwardRef<
  HTMLParagraphElement,
  React.HTMLAttributes<HTMLParagraphElement>
>(({ className, ...props }, ref) => (
  <p
    ref={ref}
    data-slot="timeline-title"
    className={cn('text-copy-sm font-medium text-fg', className)}
    {...props}
  />
))
TimelineTitle.displayName = 'TimelineTitle'

export const TimelineTime = React.forwardRef<
  HTMLTimeElement,
  React.TimeHTMLAttributes<HTMLTimeElement>
>(({ className, ...props }, ref) => (
  <time
    ref={ref}
    data-slot="timeline-time"
    className={cn('font-mono text-label-xs text-fg-muted', className)}
    {...props}
  />
))
TimelineTime.displayName = 'TimelineTime'
