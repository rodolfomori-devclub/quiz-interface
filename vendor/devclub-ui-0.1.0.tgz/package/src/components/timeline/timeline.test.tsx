import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import {
  Timeline,
  TimelineItem,
  TimelineDot,
  TimelineContent,
  TimelineTitle,
  TimelineTime,
} from './timeline'

describe('Timeline', () => {
  it('renderiza itens da jornada em uma lista ordenada', () => {
    render(
      <Timeline>
        <TimelineItem>
          <TimelineDot status="active" />
          <TimelineContent>
            <TimelineTitle>Matrícula concluída</TimelineTitle>
            <TimelineTime dateTime="2026-07-17">17 jul 2026</TimelineTime>
          </TimelineContent>
        </TimelineItem>
        <TimelineItem>
          <TimelineDot status="pending" />
          <TimelineContent>
            <TimelineTitle>Primeiro módulo</TimelineTitle>
          </TimelineContent>
        </TimelineItem>
      </Timeline>
    )
    expect(screen.getByRole('list')).toBeInTheDocument()
    expect(screen.getAllByRole('listitem')).toHaveLength(2)
    expect(screen.getByText('Matrícula concluída')).toBeInTheDocument()
    expect(screen.getByText('17 jul 2026')).toBeInTheDocument()
  })
})
