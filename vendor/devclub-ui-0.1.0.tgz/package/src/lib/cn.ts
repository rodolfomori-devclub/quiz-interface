import { clsx, type ClassValue } from 'clsx'
import { extendTailwindMerge } from 'tailwind-merge'

/**
 * tailwind-merge estendido para conhecer as escalas customizadas do DevClub.
 * Sem isso, `text-brand` (cor) e `text-h1` (tamanho) seriam tratados como o
 * mesmo grupo e um sobrescreveria o outro incorretamente.
 */
const twMerge = extendTailwindMerge({
  extend: {
    classGroups: {
      'font-size': [
        {
          text: [
            'display',
            'h1',
            'h2',
            'h3',
            'h4',
            'h5',
            'copy',
            'copy-lg',
            'copy-sm',
            'label',
            'label-sm',
            'label-xs',
            'eyebrow',
          ],
        },
      ],
      shadow: [{ shadow: ['1', '2', '3', 'glow', 'press-brand', 'press-neutral', 'press-premium', 'press-error'] }],
      rounded: [{ rounded: ['xs', 'sm', 'md', 'lg', 'xl', '2xl', 'full'] }],
    },
  },
})

/** Combina classes condicionais e resolve conflitos de Tailwind. */
export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs))
}
