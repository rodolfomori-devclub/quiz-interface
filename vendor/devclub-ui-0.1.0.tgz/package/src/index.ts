/**
 * @devclub/ui — biblioteca de componentes do DevClub Design System.
 * Estética 'Terminal Premium': verde fósforo sobre navy, dark-first, acessível.
 * Barrel gerado a partir de todos os componentes das 4 ondas.
 */

// utils
export { cn } from './lib/cn'

// --- Onda 1: fundamentais (referência) ---
export { Button, buttonVariants, type ButtonProps } from './components/button/button'
export { Badge, badgeVariants, type BadgeProps } from './components/badge/badge'
export {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
} from './components/card/card'
export { Input, inputVariants, type InputProps } from './components/input/input'
export { Spinner, type SpinnerProps } from './components/spinner/spinner'
export { Kbd, type KbdProps } from './components/kbd/kbd'

// --- Componentes gerados (ondas 1-4) ---
export type { AlertProps } from './components/alert/alert'
export type { AvatarProps, AvatarGroupProps } from './components/avatar/avatar'
export type { CalendarProps } from './components/calendar/calendar'
export type { CheckboxProps } from './components/checkbox/checkbox'
export type { CodeBlockProps } from './components/code-block/code-block'
export type { CommandDialogProps } from './components/command/command'
export type { ContextMenuItemProps, ContextMenuLabelProps, ContextMenuSubTriggerProps } from './components/context-menu/context-menu'
export type { DropdownMenuItemProps, DropdownMenuLabelProps, DropdownMenuSubTriggerProps } from './components/dropdown-menu/dropdown-menu'
export type { EmptyStateProps } from './components/empty-state/empty-state'
export type { IconButtonProps } from './components/icon-button/icon-button'
export type { LabelProps } from './components/label/label'
export type { SeparatorProps } from './components/separator/separator'
export type { SkeletonProps } from './components/skeleton/skeleton'
export type { StatCardProps, StatTrend } from './components/stat-card/stat-card'
export type { StepperProps, StepProps } from './components/stepper/stepper'
export type { SwitchProps } from './components/switch/switch'
export type { TagProps } from './components/tag/tag'
export type { TerminalHeaderProps } from './components/terminal-window/terminal-window'
export type { TextareaProps } from './components/textarea/textarea'
export type { TimelineDotProps } from './components/timeline/timeline'
export type { ToastProps } from './components/toast/toast'
export type { TooltipContentProps } from './components/tooltip/tooltip'
export { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from './components/accordion/accordion'
export { Alert, AlertTitle, AlertDescription, alertVariants } from './components/alert/alert'
export { AlertDialog, AlertDialogTrigger, AlertDialogPortal, AlertDialogOverlay, AlertDialogContent, AlertDialogHeader, AlertDialogFooter, AlertDialogTitle, AlertDialogDescription, AlertDialogAction, AlertDialogCancel } from './components/alert-dialog/alert-dialog'
export { Avatar, AvatarImage, AvatarFallback, AvatarGroup, avatarVariants } from './components/avatar/avatar'
export { Breadcrumb, BreadcrumbList, BreadcrumbItem, BreadcrumbLink, BreadcrumbPage, BreadcrumbSeparator, BreadcrumbEllipsis } from './components/breadcrumb/breadcrumb'
export { Calendar } from './components/calendar/calendar'
export { Checkbox } from './components/checkbox/checkbox'
export { CodeBlock } from './components/code-block/code-block'
export { Combobox, ComboboxTrigger, ComboboxContent, ComboboxInput, ComboboxList, ComboboxEmpty, ComboboxGroup, ComboboxItem } from './components/combobox/combobox'
export { Command, CommandDialog, CommandInput, CommandList, CommandEmpty, CommandGroup, CommandItem, CommandSeparator, CommandShortcut } from './components/command/command'
export { ContextMenu, ContextMenuTrigger, ContextMenuContent, ContextMenuItem, ContextMenuCheckboxItem, ContextMenuRadioGroup, ContextMenuRadioItem, ContextMenuLabel, ContextMenuSeparator, ContextMenuGroup, ContextMenuPortal, ContextMenuSub, ContextMenuSubTrigger, ContextMenuSubContent, ContextMenuShortcut } from './components/context-menu/context-menu'
export { Dialog, DialogTrigger, DialogPortal, DialogClose, DialogOverlay, DialogContent, DialogHeader, DialogFooter, DialogTitle, DialogDescription, type DialogContentProps } from './components/dialog/dialog'
export { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuCheckboxItem, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuGroup, DropdownMenuPortal, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent, DropdownMenuShortcut } from './components/dropdown-menu/dropdown-menu'
export { EmptyState } from './components/empty-state/empty-state'
export { Field, FieldLabel, FieldControl, FieldHint, FieldError } from './components/field/field'
export { IconButton, iconButtonSizes } from './components/icon-button/icon-button'
export { InputOTP, InputOTPGroup, InputOTPSlot, InputOTPSeparator } from './components/input-otp/input-otp'
export { Label } from './components/label/label'
export { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationPrevious, PaginationNext, PaginationEllipsis } from './components/pagination/pagination'
export { Popover, PopoverTrigger, PopoverAnchor, PopoverClose, PopoverContent } from './components/popover/popover'
export { Progress, progressVariants, type ProgressProps } from './components/progress/progress'
export { RadioGroup, RadioGroupItem } from './components/radio-group/radio-group'
export { ScrollArea, ScrollBar } from './components/scroll-area/scroll-area'
export { Select, SelectTrigger, SelectValue, SelectContent, SelectItem, SelectGroup, SelectLabel, SelectSeparator, SelectScrollUpButton, SelectScrollDownButton } from './components/select/select'
export { Separator } from './components/separator/separator'
export { Sheet, SheetTrigger, SheetPortal, SheetClose, SheetOverlay, SheetContent, SheetHeader, SheetFooter, SheetTitle, SheetDescription, sheetVariants, type SheetContentProps } from './components/sheet/sheet'
export { Sidebar, SidebarHeader, SidebarContent, SidebarFooter, SidebarNav, SidebarNavItem, SidebarGroup, SidebarGroupLabel, sidebarNavItemVariants } from './components/sidebar/sidebar'
export { Skeleton, skeletonVariants } from './components/skeleton/skeleton'
export { Slider } from './components/slider/slider'
export { StatCard, statCardVariants } from './components/stat-card/stat-card'
export { Stepper, Step, StepLabel, StepDescription } from './components/stepper/stepper'
export { Switch } from './components/switch/switch'
export { Table, TableHeader, TableBody, TableFooter, TableRow, TableHead, TableCell, TableCaption } from './components/table/table'
export { Tabs, TabsList, TabsTrigger, TabsContent, tabsListVariants, tabsTriggerVariants } from './components/tabs/tabs'
export { Tag, tagVariants } from './components/tag/tag'
export { TerminalWindow, TerminalHeader, TerminalBody } from './components/terminal-window/terminal-window'
export { Textarea, textareaVariants } from './components/textarea/textarea'
export { Timeline, TimelineItem, TimelineDot, TimelineContent, TimelineTitle, TimelineTime } from './components/timeline/timeline'
export { Toast, ToastProvider, ToastViewport, ToastTitle, ToastDescription, ToastAction, ToastClose, toastVariants } from './components/toast/toast'
export { Tooltip, TooltipProvider, TooltipTrigger, TooltipContent } from './components/tooltip/tooltip'
