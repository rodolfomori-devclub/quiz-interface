# @devclub/ui

Biblioteca de componentes React do **DevClub Design System** — estética "Terminal Premium", dark-first, acessível.

```bash
pnpm add @devclub/ui @devclub/tokens
```

```css
@import 'tailwindcss';
@import '@devclub/tokens/css';
@source '../node_modules/@devclub/ui/dist';
```

```tsx
import { Button, Card, CardHeader, CardTitle, Badge } from '@devclub/ui'
```

## Características

- **46 componentes** cobrindo formulário, feedback, overlays, navegação, dados e identidade DevClub.
- **Acessível** — construído sobre primitivos Radix, com foco visível verde, teclado e ARIA corretos.
- **Dark-first** com modo claro via `data-theme="light"`.
- **Variantes com CVA** e composição via `asChild` (Radix Slot).
- **Tailwind v4** — os estilos vêm do scan do seu Tailwind; sem CSS runtime.

## Convenção de props

- Componentes estilizados expõem `variant`/`size` (quando aplicável) e `className` para override.
- Componentes compostos seguem o padrão Radix (`Dialog` + `DialogTrigger` + `DialogContent` …).
- `asChild` para renderizar no elemento filho (ex: `<Button asChild><Link/></Button>`).

Documentação completa e galeria ao vivo no site de docs.

## Licença

MIT © DevClub
